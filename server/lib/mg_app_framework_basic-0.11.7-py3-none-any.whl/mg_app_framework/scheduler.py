from apscheduler.schedulers.tornado import TornadoScheduler
from mg_app_framework.config import Store, AppType, get_context, update_context


# 开启定时逻辑
def make_scheduler():
    scheduler = TornadoScheduler()

    trigger_args = Store.get_trigger_args()

    if trigger_args:
        trigger_type = trigger_args['trigger_type']
        value = trigger_args['value']
        if trigger_type == AppType.interval:
            scheduler.add_job(Store.get_data_func(), trigger_type, seconds=value, id='job_id')
        elif trigger_type == AppType.cron:
            scheduler.add_job(Store.get_data_func(), trigger_type,
                              year=value['year'],
                              month=value['month'],
                              day=value['day'],
                              day_of_week=value['day_of_week'],
                              hour=value['hour'],
                              minute=value['minute'],
                              second=value['second'],
                              id='job_id')
        elif trigger_type == AppType.date:
            if value:
                scheduler.add_job(Store.get_data_func(), trigger_type, run_date=value, id='job_id')
            else:
                scheduler.add_job(Store.get_data_func(), trigger_type, id='job_id')

        if Store.get_switch():
            scheduler.start()
        else:
            scheduler.start(paused=True)

        update_context('scheduler', scheduler)


# 更新定时逻辑
def update_scheduler():
    scheduler = get_context('scheduler')
    if scheduler:
        trigger_args = Store.get_trigger_args()
        if trigger_args:
            trigger_type = trigger_args['trigger_type']
            value = trigger_args['value']
            if trigger_type == AppType.interval:
                scheduler.reschedule_job('job_id', trigger=trigger_type, seconds=value)
            elif trigger_type == AppType.cron:
                scheduler.reschedule_job('job_id', trigger=trigger_type,
                                         year=value['year'],
                                         month=value['month'],
                                         day=value['day'],
                                         day_of_week=value['day_of_week'],
                                         hour=value['hour'],
                                         minute=value['minute'],
                                         second=value['second'])
            elif trigger_type == AppType.date:
                jobs = scheduler.get_jobs()
                if jobs:
                    if value:
                        scheduler.reschedule_job('job_id', trigger=trigger_type, run_date=value)
                    else:
                        scheduler.reschedule_job('job_id', trigger=trigger_type)
                else:
                    if value:
                        scheduler.add_job(Store.get_data_func(), trigger_type, run_date=value, id='job_id')
                    else:
                        scheduler.add_job(Store.get_data_func(), trigger_type, id='job_id')
