from enum import Enum, unique


@unique
class TaskKey(Enum):
    admin = 0
    opc = 1
    mongodb = 2
    mysql = 3
    websocket = 4
    opcua = 5
    oracle = 6
    init_func = 7
    ha = 8
    sds = 9
    idi = 10
    mongodb_async = 11
    idi_server = 12
    mysql_async = 13
    rabbitmq_async = 14
    redis_async = 15
    mqtt_broker_async = 16

from mg_app_framework.components.admin_connector import admin_connect
from mg_app_framework.components.opc_connector import opcda_connect, opcua_connect
from mg_app_framework.components.mongodb_connector import mongodb_connect, mongodb_async_connect
from mg_app_framework.components.mysqldb_connector import mysqldb_connect, mysqldb_async_connect
from mg_app_framework.components.websocket_connector import websocket_connect_dict
from mg_app_framework.components.oracledb_connector import oracle_connect
from mg_app_framework.components.init_func import run_userdef
from mg_app_framework.components.ha import start_ha_connect
from mg_app_framework.components.sds import sds_init_func
from mg_app_framework.components.idi import idi_connect
from mg_app_framework.components.idi_server import idi_server_connect
from mg_app_framework.components.rabbitmq_connector import rabbitmq_async_connect
from mg_app_framework.components.redis_connector import redis_async_connect
from mg_app_framework.components.mqtt_connector import mqtt_broker_async_connect

TASKS = {
    TaskKey.admin: admin_connect,
    TaskKey.opc: opcda_connect,
    TaskKey.opcua: opcua_connect,
    TaskKey.mongodb: mongodb_connect,
    TaskKey.mysql: mysqldb_connect,
    TaskKey.websocket: websocket_connect_dict,
    TaskKey.oracle: oracle_connect,
    TaskKey.init_func: run_userdef,
    TaskKey.ha: start_ha_connect,
    TaskKey.sds: sds_init_func,
    TaskKey.idi: idi_connect,
    TaskKey.mongodb_async: mongodb_async_connect,
    TaskKey.idi_server: idi_server_connect,
    TaskKey.mysql_async: mysqldb_async_connect,
    TaskKey.rabbitmq_async: rabbitmq_async_connect,
    TaskKey.redis_async: redis_async_connect,
    TaskKey.mqtt_broker_async: mqtt_broker_async_connect,
}
