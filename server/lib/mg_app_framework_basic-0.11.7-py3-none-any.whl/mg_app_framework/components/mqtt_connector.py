import os, json, copy, traceback, telnetlib, subprocess
from abc import ABCMeta, abstractmethod
import asyncio

from tornado.ioloop import IOLoop
from tornado.gen import sleep, multi

from gmqtt import Client as MQTTClient
from gmqtt.mqtt.constants import MQTTv311

from mg_app_framework.config import Store, get_logger, set_handler, get_handler, get_uuid, get_organization, \
    get_rabbitmq_info
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from inspect import iscoroutinefunction


class MQTTBrokerConfigBasic(metaclass=ABCMeta):
    def get_rabbitmq_host(self):
        return get_rabbitmq_info().get('host')

    def get_rabbitmq_port(self):
        return '1883'

    def get_rabbitmq_username(self):
        return get_rabbitmq_info().get('username')

    def get_rabbitmq_password(self):
        return get_rabbitmq_info().get('password')

    def is_config_data_publisher(self):
        """
        :return:True  -> 会处理新上线app的配置数据请求
                False -> 不会处理新上线app的配置数据请求
        """
        return False

    def get_rabbitmq_subscribe_list(self):
        """
        :return:返回订阅的数组
        [
            'kkk', # 消息索引
            'yyy', # 消息索引
            ...
        ]
        """
        return []

    @abstractmethod
    def message_process_func(self):
        """
        1. subscribe_list is not empty
        2. when receive message, call this function to process message
        message 数据格式:
        {
            'organization':'hhh' # 组织信息
            'key'  : 'kkk',      # 消息索引
            'data' : 'lll'       # 消息数据
        }
        # 消息处理函数:
        def message_func_example(message):
            if msg['key'] == 'kkk':
                get_logger().info("msg: %s" % (str(message)))
            elif msg['key'] == 'yyy':
                get_logger().info("msg: %s" % (str(message)))

        :return:返回处理函数名(message_func_example)
        """
        pass

    def set_sqlite_db_file_path(self):
        """
        设置sqlite储存数据的路径
        """
        return '/var/iot_message.db'

    def republish_fetch_message_num(self):
        '''
        :return: 重新发送时单次从sqlite取出数据条数
        '''
        return 10

    def set_disk_usage_alarm_threshold(self):
        '''
        设置iot磁盘使用率阈值
        :return:
        '''
        return 90

    def reconnect_num_threshold(self):
        """
        :return:重连broker次数阈值, 超过后会重启app或iot设备，默认60

        """
        return 60

    def reconnect_interval(self):
        """
        :return:重连broker时间间隔, 默认 5 秒

        """
        return 5


class MQTTBrokerClient:
    def __init__(self, host, port, username, password, subscribe_list, queue_name, is_config_data_publisher,
                 sqlite_db_file_path, republish_fetch_message_num, disk_usage_alarm_threshold, reconnect_num_threshold,
                 reconnect_interval, message_process_func=None):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.subscribe_list = subscribe_list
        self.queue_name = queue_name
        self.is_config_data_publisher = is_config_data_publisher
        self.subscribe_message_cache = {}
        self.publish_message_cache = {}
        self.message_process_func = message_process_func
        self.sqlite_db_file_path = sqlite_db_file_path
        self.disk_usage_alarm_threshold = disk_usage_alarm_threshold
        self.reconnect_num_threshold = reconnect_num_threshold
        self.republish_fetch_message_num = republish_fetch_message_num
        self.reconnect_interval = reconnect_interval
        self.reconnect_num = 0
        self.republish_running = False

        # 初始化客户端
        self.connection = MQTTClient(self.queue_name,
                                     clean_session=False)  # clean_session False means non-auto-deleted queue
        self.connection.on_connect = self.on_connect
        self.connection.on_message = self.on_message
        self.connection.on_disconnect = self.on_disconnect
        self.connection.on_subscribe = self.on_subscribe
        self.connection.set_config({'reconnect_delay': self.reconnect_interval})
        self.connection.set_auth_credentials(self.username, self.password)
        self.connection._resend_task.cancel()  # 禁止底层lib执行重发数据任务

    async def get_connection(self):
        if not self.connection.is_connected:
            try:
                await asyncio.wait_for(
                    self.connection.connect(self.host, port=int(self.port), version=MQTTv311), timeout=1)
                get_logger().info('connect rabbitmq success')
            except asyncio.TimeoutError:
                self.reconnect_num += 1
                get_logger().info('%sth reconnect rabbitmq failed because of timeout', self.reconnect_num)
                await asyncio.sleep(self.reconnect_interval)
                asyncio.ensure_future(self.get_connection())
            except Exception as e:
                self.reconnect_num += 1
                get_logger().info('%sth reconnect rabbitmq failed because of %s', self.reconnect_num, e)
                await asyncio.sleep(self.reconnect_interval)
                asyncio.ensure_future(self.get_connection())

    def on_connect(self, client, flags, rc, properties):
        self.reconnect_num = 0
        asyncio.ensure_future(self.subscribe())

    def on_disconnect(self, client, packet, exc=None):
        get_logger().warn('disconnected from broker [%s] [%s]', self.host, self.port)

    async def publish_message(self, msg, topic_name, time_series_data=True, republish_message=False):
        '''
        :param msg: {'key': 'test_key', 'data':  '15:02:56'}
        :param topic_name: organization
        :param time_series_data: 是否为时序数据，默认为True
        :param republish_message: 是否为重发的sqlite持久化数据，默认为False
        :return: True or False
        '''
        publish_key, publish_data = msg.get('key'), msg.get('data')
        topic = pack_message_key(topic_name, publish_key)
        self.publish_message_cache.update({topic: publish_data})

        if time_series_data:
            msg.update({'time_series_data': time_series_data})

        message = json.dumps(msg)

        publish_res = False
        if self.connection.is_connected:
            self.connection.publish(topic, message, qos=1)
            publish_res = True
            get_logger().info('publish [%s] message success', topic)
            asyncio.ensure_future(self.republish_persist_message())

        else:
            get_logger().info('publish [%s] message fail', topic)
            publish_failed_message = {'key': topic, 'data': publish_data}
            if not republish_message:  # 如果是重发消息时失败则不用存数据库
                await self.persist_publish_failed_message(publish_failed_message, time_series_data)

        return publish_res

    async def on_message(self, client, topic, payload, qos, properties):
        '''
        消息处理函数
        :param client:
        :param topic: 消息话题，root/test
        :param payload: 消息内容
        :param qos:  消息质量
        :param properties:
        :return:
        '''

        organization, routing_key = unpack_message_key(topic)
        if routing_key != 'new_subscriber_online' and routing_key not in self.subscribe_list:
            # await self.unsubscribe(routing_key)
            get_logger().debug('subscribe_key[%s] not exist in subscribe_list', routing_key)
            return 0

        message = json.loads(payload.decode("utf-8"))

        message_data = message.get('data')
        get_logger().debug('receive message by subscribe key[%s]', topic)
        get_logger().debug('message_body==%s', message_data)

        # 处理消息
        processed_message = await self.preprocess_message(message, topic)
        if processed_message:
            execute_message = {'organization': organization, 'key': routing_key, 'data': message_data}
            await self.execute_message_process_func(execute_message)

        return 0

    async def preprocess_message(self, message, topic):
        # 预处理消息，并更新订阅端缓存的配置数据
        message_key = message.get('key')
        message_data = message.get('data')
        is_time_series_data = message.get('time_series_data')

        # 直接返回业务数据
        if is_time_series_data:
            message.pop('time_series_data')
            return message

        # 处理新上线的订阅者请求
        organization = get_organization()
        if self.is_config_data_publisher:
            # 返回新上线的订阅者订阅列表中的配置数据
            if topic == pack_message_key(organization, 'new_subscriber_online'):
                get_logger().info('receive new online subscriber key list %s', message_data)
                for subscribe_key in message_data:
                    new_subscribe_key = pack_message_key(organization, subscribe_key)
                    data = self.publish_message_cache.get(new_subscribe_key)
                    if data:
                        msg = {'key': subscribe_key, 'data': data}
                        await self.publish_message(msg, organization, time_series_data=False)  # 发布配置数据
                    else:
                        get_logger().debug(
                            'cannot publish key[%s] because cache data is None', subscribe_key)
            return

        cache_message_data = self.subscribe_message_cache.get(topic)
        if json.dumps(message_data) != json.dumps(cache_message_data):
            # 如果订阅到的消息和缓存里的消息不同则直接处理
            self.subscribe_message_cache.update({topic: message_data})
            return message
        else:
            # 如果订阅到的消息和缓存里的消息相同则忽略
            get_logger().debug(
                'ignore message_key[%s] because of nothing changed comparing with subscribe_message_cache')
            return

    async def execute_message_process_func(self, execute_message):
        # 执行用户注册的消息处理函数
        if self.message_process_func:
            if iscoroutinefunction(self.message_process_func):
                await self.message_process_func(execute_message)
            else:
                self.message_process_func(execute_message)

    async def send_subscribe_key_list_to_publisher(self, subscribe_list):
        # 向配置发布者请求配置
        if not subscribe_list:
            return

        publish_key = 'new_subscriber_online'
        msg = {'key': publish_key, 'data': subscribe_list}
        await self.publish_message(msg, get_organization(), time_series_data=False)
        get_logger().info('send subscribe key list %s finished', subscribe_list)

    async def subscribe(self):
        # 订阅key
        organization = get_organization()
        for key in self.subscribe_list:
            topic = pack_message_key(organization, key)
            self.connection.subscribe(topic, qos=1)
            get_logger().info('subscribe key[%s] finished', topic)

        # 订阅new_subscriber_online消息
        if self.is_config_data_publisher:
            topic = pack_message_key(organization, 'new_subscriber_online')
            self.connection.subscribe(topic, qos=1)
            get_logger().info('subscribe key[%s] finished', topic)

    def on_subscribe(self, client, mid, qos, properties):
        get_logger().info('subscribe success')

    async def unsubscribe(self, key):
        # 解除订阅，有点问题尚未解决
        organization = get_organization()
        topic = pack_message_key(organization, key)
        self.connection.unsubscribe(topic)
        get_logger().info('unsubscribe key[%s] finished', topic)

    async def check_network_condition(self):
        '''
        超过重连阈值后检查网络是否通畅,iot定制逻辑
        :return:
        '''
        while True:
            if (not self.connection.is_connected) and (
                    self.reconnect_num > self.reconnect_num_threshold or
                    self.connection.failed_connections > self.reconnect_num_threshold):
                if is_port_open(self.host, self.port):
                    get_logger().info('reconnect failed and network is unavailable, start restart_process')
                    self.restart_process()
                else:
                    get_logger().info('reconnect failed but network is available, start restart_iot')
                    self.restart_iot()

            await sleep(self.reconnect_interval)
            get_logger().info('execute check_network_condition')

    def restart_process(self):
        '''
        重连失败但网络不通重启采集进程
        :return:
        '''
        p = subprocess.Popen('ps | grep run_idi_iot', shell=True, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)

        pid_list = []
        for line in p.stdout.readlines():
            info = line.decode('utf-8')
            if 'python' in info and 'run_idi_iot' in info:
                pid = str(int(info[:6]))
                if pid not in pid_list:
                    pid_list.append(pid)

        if pid_list:
            kill_cmd = 'kill -9 ' + ' '.join(pid_list)
            restart_process_cmd = kill_cmd + ';' + 'bash /home/root/idi_iot_0.0.4/bin/run.sh start'
            get_logger().info('start execute reconnect_fail_cmd:%s', restart_process_cmd)
            os.system(restart_process_cmd)
        else:
            get_logger().info('not found pid')

    def restart_iot(self):
        '''
        重连失败且网络不通时重启iot设备
        :return:
        '''
        restart_iot_cmd = 'reboot'
        get_logger().info('start execute reconnect_fail_cmd:%s', restart_iot_cmd)
        os.system(restart_iot_cmd)

    async def persist_publish_failed_message(self, message, time_series_data):
        # 持久化储存发送失败的消息至本地数据库
        try:
            if time_series_data and (not get_disk_usage_alarm(self.disk_usage_alarm_threshold)):
                from aiosqlite import connect as aiosqlite_connect
                async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
                    await self.create_table_in_sqlite()
                    await sqlite_db.execute("INSERT INTO publish_failed_time_series_data VALUES (null,?)",
                                            (json.dumps(message),))
                    await sqlite_db.commit()
                    get_logger().info('persist_publish_failed_message to sqlite finished')

        except Exception as e:
            get_logger().info('persist_publish_failed_message to sqlite failed:%s', e)

    async def create_table_in_sqlite(self):
        table_list = []
        from aiosqlite import connect as aiosqlite_connect
        async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
            c = await sqlite_db.execute("SELECT name FROM sqlite_master WHERE type='table';")
            async for row in c:
                table_list.append(row[0])

            if 'publish_failed_time_series_data' not in table_list:
                await sqlite_db.execute("PRAGMA auto_vacuum = FULL;")
                await sqlite_db.execute(
                    '''create table IF NOT EXISTS publish_failed_time_series_data(message_id INTEGER PRIMARY KEY,message TEXT )''')
                get_logger().info('create_table_in_sqlite finished')

    async def republish_persist_message(self):
        # 将发送失败的消息从本地数据库（sqlite）读取出来然后发布出去
        if not self.republish_running:
            self.republish_running = True  # 重新发布数据任务开始
            try:
                table_list = []
                from aiosqlite import connect as aiosqlite_connect
                async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
                    c = await sqlite_db.execute("SELECT name FROM sqlite_master WHERE type='table';")
                    async for row in c:
                        table_list.append(row[0])

                    if 'publish_failed_time_series_data' in table_list:
                        while True:
                            select_sql = "SELECT message_id, message FROM publish_failed_time_series_data where message_id>=0 limit {}".format(
                                self.republish_fetch_message_num)
                            async with sqlite_db.execute(select_sql) as cursor:
                                rows = await cursor.fetchmany(self.republish_fetch_message_num)
                                if (not rows) or (not self.connection.is_connected):
                                    break

                                coro_dict = {}
                                for row in rows:
                                    message_id, message = row[0], json.loads(row[1])
                                    organization, message['key'] = unpack_message_key(message.get('key'))
                                    coro_dict[str(message_id)] = self.publish_message(message, organization,
                                                                                      time_series_data=True,
                                                                                      republish_message=True)
                                results = await multi(coro_dict)
                                publish_success_id_list = [id for id, res in results.items() if res]
                                delete_list = '(' + ','.join(publish_success_id_list) + ')'
                                delete_sql = "delete FROM publish_failed_time_series_data where message_id IN {}".format(
                                    delete_list)
                                await sqlite_db.execute(delete_sql)
                                await sqlite_db.commit()

                        if self.connection.is_connected:
                            await sqlite_db.execute('DROP TABLE publish_failed_time_series_data')
                            await sqlite_db.execute("VACUUM")
                            await sqlite_db.commit()
                            get_logger().debug('republish job finished')
                        else:
                            get_logger().info('republish job paused because of connection is None')

            except  Exception as e:
                get_logger().info('republish persist message from sqlite failed:%s', e)
            finally:
                self.republish_running = False  # 重新发布数据任务停止

        else:
            get_logger().debug('republish job is running')


async def mqtt_publish_many(datas, time_series_data=True):
    '''
    :param datas:
                    # [
                    # {
                    #     'organization':'realtech'
                    #     'key': key_name1,
                    #     'data': ...
                    # },
                    # {
                    #     'organization':'realtech'
                    #     'key': key_name2,
                    #     'data': ...
                    # },
                    # ]
    :param time_series_data: 是否为时序数据（业务数据）
    :return:
    '''

    await multi([mqtt_publish_one(data, time_series_data) for data in datas])


async def mqtt_publish_one(data, time_series_data=True):
    '''
    :param data:    # {
                    #   'organization':'realtech'
                    #   'key': key_name,
                    #   'data': ...
                    # }
    :param time_series_data: 是否为时序数据（业务数据）
    :return:
    '''
    message = copy.deepcopy(data)
    topic_name = get_organization() if not message.pop('organization', None) else get_organization()

    mqtt_broker_handler = get_handler(TaskKey.mqtt_broker_async)
    await mqtt_broker_handler.publish_message(message, topic_name, time_series_data)


def get_disk_usage_alarm(disk_usage_alarm_threshold):
    '''
    磁盘使用率超过阈值则告警
    :return:
    '''
    import psutil
    disk_usage_alarm = False
    disk_info = psutil.disk_usage('/')
    percent = round(disk_info.percent, 2)
    if percent > disk_usage_alarm_threshold:
        disk_usage_alarm = True
        get_logger().info('disk usage[%s] higher than threshold[%s]', percent, disk_usage_alarm_threshold)

    return disk_usage_alarm


def pack_message_key(topic_name, routing_key, slash='/'):
    # 将topic_name和routing_key包装成新的message key, MQTT主题段分隔符使用斜杠（“ /”）而AMQP 0-9-1使用点
    return slash.join([topic_name, routing_key])


def unpack_message_key(message_key, slash='/'):
    return message_key.split(slash)


def is_port_open(ip, port):
    is_open = False
    try:
        tn = telnetlib.Telnet(ip, port, timeout=1)
        is_open = True
        tn.close()
    except:
        pass

    return is_open


class MQTTBrokerConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def mqtt_broker_async_connect(conn_time=None):
    # 初始化客户端连接配置
    store = Store.get_init_task_config(TaskKey.mqtt_broker_async)
    host = store.get_rabbitmq_host()
    port = int(store.get_rabbitmq_port())
    username = store.get_rabbitmq_username()
    password = store.get_rabbitmq_password()
    is_config_data_publisher = store.is_config_data_publisher()
    subscribe_list = store.get_rabbitmq_subscribe_list()
    queue_name = get_uuid()
    message_process_func = store.message_process_func()
    sqlite_db_file_path = store.set_sqlite_db_file_path()
    disk_usage_alarm_threshold = store.set_disk_usage_alarm_threshold()
    republish_fetch_message_num = store.republish_fetch_message_num()
    reconnect_num_threshold = store.reconnect_num_threshold()
    reconnect_interval = store.reconnect_interval()

    mqtt_broker_handler = MQTTBrokerClient(host, port, username, password, subscribe_list, queue_name,
                                           is_config_data_publisher, sqlite_db_file_path, republish_fetch_message_num,
                                           disk_usage_alarm_threshold, reconnect_num_threshold,
                                           reconnect_interval, message_process_func)

    # 建立连接
    await mqtt_broker_handler.get_connection()  # create connection
    set_handler(TaskKey.mqtt_broker_async, mqtt_broker_handler)
    if mqtt_broker_handler.connection.is_connected:
        await mqtt_broker_handler.send_subscribe_key_list_to_publisher(subscribe_list)

    start_next_task(TaskKey.mqtt_broker_async)
    asyncio.ensure_future(mqtt_broker_handler.check_network_condition())
