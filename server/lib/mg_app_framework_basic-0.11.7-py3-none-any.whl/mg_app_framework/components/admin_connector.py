from tornado import websocket, gen
import json
from mg_app_framework.config import Store, set_handler, get_logger, update_context, AppType
from mg_app_framework.message import MesType, send_mes
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
import os
from os.path import dirname
import base64


class AdminConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class UuidNotRegisterError(Exception):
    pass


class UuidRepeatError(Exception):
    pass


# connect to the mg_manager
async def admin_connect(re_conn=True, conn_time=None, debug=False):
    connect_mark = True

    # 根据config 中connect_admin的配置决定是否需要连接manager, 默认连接manager
    connect_admin = Store.store.connect_admin()
    if not connect_admin:
        connect_mark = False

    if connect_mark:
        __cnt = 0
        while True:
            admin_handler = ''
            try:
                # 重构之后conn_time永远为None, 无限重连
                if conn_time and __cnt == int(conn_time):
                    get_logger().error('Admin connect error,connect more than ' + str(conn_time) + ' times')
                    raise AdminConnectError
                websocket_url = Store.get_websocket_url()
                admin_handler = await websocket.websocket_connect(websocket_url, ping_interval=30)
                init_config_data = Store.get_data(debug)
                get_logger().debug('向mg_manager发送初始配置数据: {}'.format(init_config_data))
                await send_mes(admin_handler, MesType.init_config, init_config_data)
                message_str = await admin_handler.read_message()
                message = json.loads(message_str)
                if message['type'] == MesType.init_config:
                    if 'app_uuid_register_check' in message['data'] and not message['data']['app_uuid_register_check']:
                        get_logger().error('appid未注册,无法上线')
                        raise UuidNotRegisterError
                    if 'app_uuid_check' in message['data'] and not message['data']['app_uuid_check']:
                        get_logger().error('app_uuid repeat')
                        raise UuidRepeatError
                    if 'name_check' in message['data'] and not message['data']['name_check']:
                        get_logger().warning('app_name repeat')
                    if 'organization' in message['data']:
                        # 获取组织信息
                        update_context('organization', message['data']['organization'])
                    if 'organization_all' in message['data']:
                        # 获取组织信息
                        update_context('organization_all', message['data']['organization_all'])
                    if 'mongodb_cluster' in message['data']:
                        # 获取mg平台mongodb集群信息
                        update_context('mongodb_cluster', message['data']['mongodb_cluster'])
                    if 'rabbitmq' in message['data']:
                        # 获取mg平台rabbitmq信息
                        update_context('rabbitmq', message['data']['rabbitmq'])
                    if 'app_logo' in message['data']:
                        # 从manager获取初始的logo数据
                        logo_data = message['data']['app_logo']
                        if logo_data:
                            Store.store.get_data().update({'app_logo': logo_data})
                    if 'app_title_logo' in message['data'] and message['data']['app_title_logo']:
                        # 从manager获取页签的logo图片覆盖本地图片
                        title_logo_base64 = message['data']['app_title_logo']
                        # 更新页签图标
                        app_type = Store.get_app_type()
                        app_module_name = Store.get_app_module_name()
                        title_logo_path = None
                        if app_type == AppType.user:
                            if app_module_name:
                                title_logo_path = os.path.join(dirname(dirname(Store.get_module_dir())), 'static',
                                                               'dist', app_module_name, 'statics', 'logo.png')
                            else:
                                title_logo_path = os.path.join(dirname(dirname(Store.get_module_dir())), 'static',
                                                               'dist', 'statics', 'logo.png')
                        elif app_type == AppType.module or app_type == AppType.portal:
                            if app_module_name:
                                title_logo_path = os.path.join(dirname(dirname(Store.get_module_dir())), 'static',
                                                               'dist', app_module_name, 'logo.png')
                        get_logger().debug('title_logo_path: {}'.format(title_logo_path))

                        if title_logo_path and os.path.exists(title_logo_path):
                            with open(title_logo_path, "wb") as title_img_writer:
                                title_img_writer.write(base64.decodebytes(title_logo_base64.encode('ascii')))

                    if 'config' in message['data']:
                        old_config = message['data']['config']
                        Store.store.get_data().update(old_config)
                        get_logger().info('从manager获取老配置: {}'.format(old_config))

                get_logger().info('admin connected successfully')
                set_handler(TaskKey.admin, admin_handler)
                if not re_conn:
                    # 运行下一步初始化
                    start_next_task(TaskKey.admin)
                    break
                else:
                    return admin_handler
            except Exception as e:
                __cnt += 1
                get_logger().exception('admin connecting retry number: {}, exception: {}'.format(str(__cnt), str(e)))
                if admin_handler:
                    get_logger().exception('admin_handler close')
                    admin_handler.close()
                await gen.sleep(30)
    else:
        start_next_task(TaskKey.admin)
