import datetime
import time
from tornado import gen
from mg_app_framework.config import Store, get_logger, set_handler, get_handler, get_store, set_context, get_context, \
    update_context, get_organization, get_mongodb_cluster_info
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from mg_app_framework.message import MesCode
from abc import ABCMeta
from tornado.gen import multi


class IdiServerConfigBasic(metaclass=ABCMeta):
    def get_mongodb_host(self):
        return get_mongodb_cluster_info().get('host')

    def get_mongodb_port(self):
        return get_mongodb_cluster_info().get('port')

    def retry_interval(self):
        return 5


class MongodbConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def idi_server_connect(re_conn=True, conn_time=None):
    import motor
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error(
                    'Idi server mongodb async connect error,connect more than ' + str(conn_time) + ' times')
                raise MongodbConnectError
            store = Store.get_init_task_config(TaskKey.idi_server)
            mongodb_host = store.get_mongodb_host()
            mongodb_port = int(store.get_mongodb_port())
            connector = motor.motor_tornado.MotorClient(mongodb_host, mongodb_port)
            get_logger().info('Idi server mongodb async connected successfully')
            set_handler(TaskKey.idi_server, connector)
            if not re_conn:
                start_next_task(TaskKey.idi_server)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('Idi server mongodb async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.idi_server)
            await gen.sleep(store.retry_interval())


async def idi_createTable(collection_name, indexs, sharding_colunms=None):
    # collection_name = "datas"
    # sharding_colunms = ["code"]
    # indexs = [("code", 1), ("timestamp", 1)]
    result_code = MesCode.success
    factory_name = get_organization()
    app_name = get_store().data.get('app_name')
    if not collection_name or not indexs:
        get_logger().warn(
            '[%s] createtable factory_name[%s], collection_name[%s] failed, collection_name or indexs is empty',
            app_name, factory_name, collection_name)
        return MesCode.fail
    get_logger().info('[%s] createtable factory_name[%s], collection_name[%s], sharding_colunm %s, indexs %s',
                      app_name, factory_name, collection_name, sharding_colunms, indexs)

    try:
        handle = get_handler(TaskKey.idi_server)
        db_name = 'idi_' + factory_name
        create_db = handle[db_name]
        collection_names = await create_db.list_collection_names(False)
        if collection_name not in collection_names:
            collection_current = await create_db.create_collection(collection_name)
            await collection_current.create_index(indexs, unique=True)
            if sharding_colunms:
                admin_db_handle = handle.admin
                abs_path = '{}.{}'.format(db_name, collection_name)
                await admin_db_handle.command('enablesharding', db_name)
                sharding_keys = {sharding_colunm: 'hashed' for sharding_colunm in sharding_colunms}
                await admin_db_handle.command('shardcollection', abs_path, key=sharding_keys)
        else:
            get_logger().warn('[%s] createtable factory_name[%s], collection_name[%s], table already exists',
                              app_name, factory_name, collection_name)
    except Exception as e:
        get_logger().error('[%s] createtable factory_name[%s], collection_name[%s] failed, %s', app_name, factory_name,
                           collection_name, str(e))
        result_code = MesCode.fail
    else:
        get_logger().info('[%s] createtable factory_name[%s] collection_name[%s] success', app_name,
                          factory_name, collection_name)
    return result_code


async def idi_dropTable(collection_name):
    factory_name = get_organization()
    app_name = get_store().data.get('app_name')
    if not collection_name:
        get_logger().warn('[%s] droptable factory_name[%s], collection_name[%s] failed, collection_name is empty',
                          app_name, factory_name, collection_name)
        return MesCode.fail
    get_logger().info('[%s] droptable factory_name[%s], collection_name[%s]', app_name, factory_name, collection_name)

    try:
        handle = get_handler(TaskKey.idi_server)
        db_name = 'idi_' + factory_name
        drop_db = handle[db_name]
        collection_names = await drop_db.list_collection_names(False)
        if collection_name not in collection_names:
            get_logger().error('[%s] droptable factory_name[%s], collection_name[%s] failed, table does not exist',
                               app_name, factory_name, str(collection_name))
            return MesCode.fail
        await drop_db.drop_collection(collection_name)
    except Exception as e:
        get_logger().error('[%s] droptable factory_name[%s], collection_name[%s] failed, %s', app_name, factory_name,
                           collection_name, str(e))
        result_code = MesCode.fail
    else:
        get_logger().info('[%s] droptable factory_name[%s] collection_name[%s] success', app_name,
                          factory_name, collection_name)
        result_code = MesCode.success

    return result_code


async def idi_insertData(datas, collection_name=None):
    # data_formate:
    # data = [{'code': ('opc_test0', 'zhangsan'), 'timestamp': '2018-11-28 11:15:23', value': 74}]
    factory_name = get_organization()
    app_name = get_store().data.get('app_name')

    try:
        handle = get_handler(TaskKey.idi_server)
        db_name = 'idi_' + factory_name
        if not collection_name:
            collection_name = 'idi_datas'
        insert_db = handle[db_name]
        collection_names = await insert_db.list_collection_names(False)
        if collection_name not in collection_names:
            result = await idi_createTable(collection_name=collection_name, indexs=[("code", 1), ("timestamp", 1)],
                                           sharding_colunms=["code"])
            if result == MesCode.fail:
                return MesCode.fail
        collection = insert_db.get_collection(collection_name)
        data_list = []
        for data in datas:
            if 'code' not in data.keys():
                get_logger().error('[%s] insert factory_name[%s] collection_name[%s] datas error: %s', app_name,
                                   factory_name, collection_name, 'code not exists')
                return MesCode.fail
            code_value = data.get('code')
            if not code_value:
                get_logger().error('[%s] insert factory_name[%s] collection_name[%s] datas error: %s', app_name,
                                   factory_name, collection_name, 'code value not exists')
                return MesCode.fail

            keys = {}
            code_value = '~'.join(sorted(code_value)) if isinstance(code_value, tuple) else code_value
            keys.update({'code': code_value})
            value = data.get('value')
            if 'timestamp' in data.keys():
                timestamp = datetime.datetime.strptime(data['timestamp'], "%Y-%m-%d %H:%M:%S")
                keys.update({'timestamp': timestamp})
            original_doc = await collection.find_one_and_update(
                keys, {'$set': {'value': value}}, projection={'_id': False})
            if not original_doc:
                data.update(keys)
                data_list.append(data)
        if data_list:
            await collection.insert_many(data_list, ordered=False)
    except Exception as e:
        get_logger().error('[%s] insert factory_name[%s] collection_name[%s] datas error: %s', app_name, factory_name,
                           collection_name, str(e))
        result_code = MesCode.fail
    else:
        get_logger().info('[%s] insert factory_name[%s] collection_name[%s] datas success', app_name,
                          factory_name, collection_name)
        result_code = MesCode.success
    return result_code


async def idi_getDatasByfilter(filters, collection_name=None):
    # filters = [{'code': 'opc_test0', "user": "p1"},
    #            {'code': 'opc_test1', "user": "p1"}]
    get_logger().info('get history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    get_logger().info('get history datas params: %s.', str(filters))
    datas = []
    request_data = []
    if not collection_name:
        collection_name = 'idi_datas'

    async def get_data(filter):
        try:
            organization_name = get_organization()
            db_name = 'idi_' + organization_name
            handle = get_handler(TaskKey.idi_server)
            query_db = handle[db_name]
            collection = query_db.get_collection(collection_name)
            documents = collection.find(filter, projection={'_id': False})
            async for document in documents:
                datas.append(document)
        except Exception as e:
            get_logger().exception(e)

    for filter in filters:
        request_data.append({
            "collection_name": collection_name,
            "filter": filter
        })
    if request_data:
        await multi(get_data(i["filter"]) for i in request_data)
    get_logger().info('response history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    return datas


async def idi_getHistoryTimeDatasByCodes(codelist, collection_name=None):
    # codelist = [{"code": ('opc_test0', 'zhangsan') "start_time": start_time, "end_time": end_time},
    # {"code": ('opc_test1', 'wangwu'), "start_time": start_time, "end_time": end_time}]
    get_logger().info('get history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    get_logger().info('get history datas params: %s.', str(codelist))
    datas = {}
    request_data = []

    if not collection_name:
        collection_name = 'idi_datas'
    if not codelist:
        return MesCode.fail
    for params in codelist:
        if not params:
            get_logger().error('参数为空')
            return MesCode.fail

        code_name = params['code']
        if not code_name:
            get_logger().error('编码名为空')
            return MesCode.fail

        code_value = '~'.join(sorted(code_name)) if isinstance(code_name, tuple) else code_name

        start_time = params.get('start_time')
        end_time = params.get('end_time')

        if not start_time:
            get_logger().error('开始时间为空')
            return MesCode.fail
        else:
            if '24:00:00' in start_time:
                get_logger().error('时间不能为24:00:00,请改为00:00:00')
                return MesCode.fail
            else:
                try:
                    datetime.datetime.strptime(start_time.split(' ')[0], '%Y-%m-%d').timestamp()
                except Exception as e:
                    get_logger().error('开始时间格式错误')
                    return MesCode.fail
        if not end_time:
            end_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            time.mktime(datetime.date.today().timetuple())
        else:
            if '24:00:00' in end_time:
                get_logger().error('时间不能为24:00:00,请改为00:00:00')
                return MesCode.fail
            else:
                try:
                    datetime.datetime.strptime(end_time.split(' ')[0], '%Y-%m-%d').timestamp()
                except Exception as e:
                    get_logger().error('结束时间格式错误')
                    return MesCode.fail

        datas.update({code_name: {}})
        request_data.append({
            "code_name": code_name,
            "code_value": code_value,
            "start_time": start_time,
            "end_time": end_time
        })

    async def get_data(code_name, code_value, start_time=None, end_time=None):
        try:
            organization_name = get_organization()
            data = {}
            handle = get_handler(TaskKey.idi_server)
            db_name = 'idi_' + organization_name
            query_db = handle[db_name]
            collection = query_db.get_collection(collection_name)
            documents = collection.find(
                {'code': code_value, 'timestamp': {'$gte': datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S"),
                                                   '$lte': datetime.datetime.strptime(end_time,
                                                                                      "%Y-%m-%d %H:%M:%S")}}).sort(
                [("timestamp", 1)])
            async for document in documents:
                ts = document['timestamp'].strftime("%Y-%m-%d %H:%M:%S")
                value = document['value']
                data.update({ts: value})
            datas[code_name] = data
        except Exception as e:
            get_logger().exception(e)

    if request_data:
        await multi(
            get_data(i["code_name"], i["code_value"], i["start_time"], i["end_time"]) for i in request_data)
    get_logger().info('response history datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    return datas


async def idi_getLastestTimeDatasByCodes(codelist, collection_name=None, limit=7, direction=2):
    # codelist = [{"code": ('opc_test0', 'zhangsan'), "start_time": start_time, "end_time": end_time},
    # {"code": ('opc_test1', 'wangwu'), "start_time": start_time, "end_time": end_time}]
    # direction 0:forward 1:backward 2:both
    get_logger().info('get lastest datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    get_logger().info('get lastest datas params: %s.', str(codelist))
    datas = {}
    request_data = []

    if not collection_name:
        collection_name = 'idi_datas'
    if limit <= 0:
        get_logger().error('起始时间不等于结束时间')
        return MesCode.fail

    for params in codelist:
        if not params:
            get_logger().error('参数为空')
            return MesCode.fail
        code_name = params['code']
        if not code_name:
            get_logger().error('编码名为空')
            return MesCode.fail

        code_value = '~'.join(sorted(code_name)) if isinstance(code_name, tuple) else code_name

        start_time = params.get('start_time')
        end_time = params.get('end_time')

        if '24:00:00' in start_time or '24:00:00' in end_time:
            get_logger().error('时间不能为24:00:00,请改为00:00:00')
            return MesCode.fail

        if start_time != end_time:
            get_logger().error('起始时间不等于结束时间')
            return MesCode.fail

        datas.update({code_name: {}})
        request_data.append({
            "code_name": code_name,
            "code_value": code_value,
            "start_time": start_time,
            "limit": limit,
            "direction": direction
        })

    async def get_data(code_name, code_value, start_time, limit, direction):
        try:
            organization_name = get_organization()
            data = {}
            handle = get_handler(TaskKey.idi_server)
            db_name = 'idi_' + organization_name
            query_db = handle[db_name]
            collection = query_db.get_collection(collection_name)
            time_now = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))
            documents = []
            if start_time == '':
                async for document in collection.find({'code': code_value,
                                                       'timestamp': {'$lte': datetime.datetime.strptime(time_now,
                                                                                                        "%Y-%m-%d %H:%M:%S")}}).sort(
                    [("timestamp", -1)]).limit(limit):
                    if document not in documents:
                        documents.append(document)

            else:
                if direction == 0:
                    async for document in collection.find({'code': code_value,
                                                           'timestamp': {'$lte': datetime.datetime.strptime(start_time,
                                                                                                            "%Y-%m-%d %H:%M:%S")}}).sort(
                        [("timestamp", -1)]).limit(limit):
                        if document not in documents:
                            documents.append(document)
                elif direction == 1:
                    async for document in collection.find({'code': code_value,
                             'timestamp': {'$gte': datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")}}).sort(
                        [("timestamp", 1)]).limit(limit):
                        if document not in documents:
                            documents.append(document)
                else:
                    limit = int(limit / 2 if limit % 2 == 0 else (limit +1) / 2)
                    print(limit)
                    async for document in collection.find({'code': code_value,
                                                           'timestamp': {'$lte': datetime.datetime.strptime(start_time,
                                                                                                            "%Y-%m-%d %H:%M:%S")}}).sort(
                        [("timestamp", -1)]).limit(limit):
                        if document not in documents:
                            documents.append(document)

                    async for document in collection.find({'code': code_value,
                             'timestamp': {'$gte': datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")}}).sort(
                        [("timestamp", 1)]).limit(limit):
                        if document not in documents:
                            documents.append(document)

            documents = sorted(documents, key=lambda x: x['timestamp'])
            for document in documents:
                ts = document['timestamp'].strftime("%Y-%m-%d %H:%M:%S")
                value = document['value']
                data.update({ts: value})

            datas[code_name] = data
        except Exception as e:
            get_logger().exception(e)

    if request_data:
        await multi(get_data(i["code_name"], i["code_value"], i["start_time"], i["limit"], i["direction"]) for i in
                    request_data)
    get_logger().info('response lastest datas time : %s.',
                      str(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))))
    return datas
