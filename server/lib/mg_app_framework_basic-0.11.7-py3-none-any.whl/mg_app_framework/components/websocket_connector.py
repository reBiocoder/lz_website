from tornado import websocket, gen
from abc import ABCMeta, abstractmethod
import json
from mg_app_framework.config import Store, get_handler, set_handler, get_logger
from mg_app_framework.components import TaskKey
import tornado
from mg_app_framework.message import MesCode
from mg_app_framework.process import start_next_task


class WebSocketConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class WebSocketConfigBasic(metaclass=ABCMeta):
    """
    return the websockets need to connect,you can overwrite this method like this:
    def get_websocket_url_dict(self):
        return {
            "websocket_url_first":["ws://127.0.0.1/websocket_url",websocket_first_process_func]
            "websocket_url_second":["ws://127.0.0.1/websocket_url_second",websocket_second_process_func]
        }
    """

    @abstractmethod
    def get_websocket_url_dict(self):
        pass

    def retry_interval(self):
        return 5


class WebSocketClient:
    """
    init a websocket client ,it is necessary to mention self.cli is None,if you want get a websocket conn ,you should
    execute get_client,just like this:
        client = WebSocketClient(url)
        conn = await get_client
    but at most time ,you need not to get the conn ,you can send message by 'send' and receive message by 'receive'
    """

    def __init__(self, url, receive_process_func=None, ping_interval=30):
        self.url = url
        self.cli = None
        self.ping_interval = ping_interval
        self.receive_process_func = receive_process_func

    async def get_client(self):
        if not self.cli:
            self.cli = await websocket.websocket_connect(self.url, ping_interval=self.ping_interval)
            get_logger().info('websocket connected successfully')
        return self.cli

    def set_url(self, url):
        self.url = url
        self.close()
        self.cli = None

    async def _send_back(self, data):
        while True:
            try:
                await self.cli.write_message(json.dumps(data))
                break
            except Exception as e:
                await tornado.gen.sleep(5)
                get_logger().exception('websocket  connected error: %s' % str(e))

    async def send(self, data, response=False, resend=False):
        """
        send the given data to the other side of websocket,
        if you need to receive message ,set the resposen True,and this method will return the message
        or keep reponse False.
        if message send error, this method will retry in 5 seconds ,until the message send success.
        example:
            cli = WebSocketClient(url)
            data = {"test":"send data"]
            cli.send(data)
        """
        try:
            await self.cli.write_message(json.dumps(data))
            if response:
                msg = await self.cli.read_message()
                return json.loads(msg) if msg else {}
            return MesCode.success
        except Exception as e:
            get_logger().exception('websocket send message fail: %s' % str(e))
            self.cli = None
            from tornado.ioloop import IOLoop
            ioloop = IOLoop.current()
            if resend:
                ioloop.spawn_callback(self._send_back)
            return MesCode.fail

    def send_sync(self, data, response=False):
        try:
            self.cli.write_message(json.dumps(data))
            if response:
                msg = self.cli.read_message()
                return json.loads(msg) if msg else {}
            return MesCode.success
        except Exception as e:
            get_logger().exception('websocket send message fail: %s' % str(e))
            self.cli = None
            return MesCode.fail

    async def receive(self):
        """
            receive message from the other side of websocket
            if messgae is "",retry in 5 seconds
        """
        while True:
            try:
                await self.get_client()
                msg = await self.cli.read_message()
                if msg:
                    return json.loads(msg)
                else:
                    await tornado.gen.sleep(5)
                    self.cli = None
            except Exception as e:
                get_logger().exception('websocket receive message fail: %s' % str(e))
                await tornado.gen.sleep(5)
                self.cli = None

    def receive_cycle(self, ioloop=None):
        """
        receive message cycle,if weboscket is closed,retry every 5 seconds
        """
        if not ioloop:
            from tornado.ioloop import IOLoop
            ioloop = IOLoop.current()

        async def _cycle():
            while True:
                try:
                    await self.get_client()
                    msg = await self.cli.read_message()
                    if msg:
                        if self.receive_process_func:
                            await self.receive_process_func(msg)
                    else:
                        await tornado.gen.sleep(5)
                        self.cli = None
                except Exception as e:
                    await tornado.gen.sleep(5)
                    self.cli = None
                    get_logger().exception('websocket  connected error: %s' % str(e))

        ioloop.spawn_callback(_cycle)

    def close(self):
        if self.cli:
            self.cli.close()


# connect to the websocket
async def websocket_connect_dict(conn_time=None):
    websocket_handler_dict = {}
    try:
        store = Store.get_init_task_config(TaskKey.websocket)
        websocket_url_dict = store.get_websocket_url_dict()  # get websocket config
        for websocket_name, [websocket_url, websocket_process_func] in websocket_url_dict.items():
            __cnt = 0
            while True:
                try:
                    if conn_time and __cnt == int(conn_time):
                        get_logger().error('Admin connect error,connect more than ' + str(conn_time) + ' times')
                        raise WebSocketConnectError
                    websocket_handler = WebSocketClient(websocket_url, websocket_process_func)  # init websocket client
                    await websocket_handler.get_client()  # connect websocket
                    websocket_handler_dict[websocket_name] = websocket_handler
                    get_logger().info('%s:%s websocket connected successfully' % (websocket_name, websocket_url))
                    break
                except Exception:
                    __cnt += 1
                    get_logger().exception(
                        '%s:%s websocket connecting retry number: %d ' % (websocket_name, websocket_url, __cnt))
                    store = Store.get_init_task_config(TaskKey.websocket)
                    await gen.sleep(store.retry_interval())
    except Exception as e:
        get_logger().exception('websocket connected fail:%s' % str(e))
    else:
        set_handler(TaskKey.websocket, websocket_handler_dict)
        start_next_task(TaskKey.websocket)


async def update_websocket_config_process(update_dict):
    """
    change the websocket connector whose websocket_name in update_dict
    ..example:
        update_dict = {
        "websocket_url_first":"ws://127.0.0.1/websocket_url",
        "websocket_url_second":"ws://127.0.0.1/websocket_url_second",
        }
        the key of update_dict should in your websocket_url_dict config,
        and the value is the new websocket_url you want to change connect to
    """
    try:
        websocket_handler_dict = get_handler(TaskKey.websocket)
        for websocket_name, websocket_url in update_dict.items():
            if websocket_name in websocket_handler_dict.keys():
                if websocket_url != websocket_handler_dict[websocket_name].url:
                    get_logger().info("update websocket url : %s" % str(websocket_url))
                    websocket_handler_dict[websocket_name].set_url(websocket_url)
    except Exception as e:
        get_logger().exception("update websocket connector error : %s" % str(e))
