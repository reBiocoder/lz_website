from abc import ABCMeta, abstractmethod
from tornado import gen

from mg_app_framework.config import Store, set_handler, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class MongodbConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class MongodbConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_mongodb_host(self):
        pass

    @abstractmethod
    def get_mongodb_port(self):
        pass

    def retry_interval(self):
        return 5


# connect to mongodb_server
async def mongodb_connect(re_conn=True, conn_time=None):
    import pymongo
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Mongodb connect error,connect more than ' + str(conn_time) + ' times')
                raise MongodbConnectError
            store = Store.get_init_task_config(TaskKey.mongodb)
            mongodb_host = store.get_mongodb_host()
            mongodb_port = int(store.get_mongodb_port())
            connector = pymongo.MongoClient(mongodb_host, mongodb_port)
            get_logger().info('mongodb connected successfully')
            set_handler(TaskKey.mongodb, connector)
            if not re_conn:
                start_next_task(TaskKey.mongodb)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('mongodb connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.mongodb)
            await gen.sleep(store.retry_interval())


async def mongodb_async_connect(re_conn=True, conn_time=None):
    import motor
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Mongodb async connect error,connect more than ' + str(conn_time) + ' times')
                raise MongodbConnectError
            store = Store.get_init_task_config(TaskKey.mongodb_async)
            mongodb_host = store.get_mongodb_host()
            mongodb_port = int(store.get_mongodb_port())
            connector = motor.motor_tornado.MotorClient(mongodb_host, mongodb_port)
            get_logger().info('mongodb async connected successfully')
            set_handler(TaskKey.mongodb_async, connector)
            if not re_conn:
                start_next_task(TaskKey.mongodb_async)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('mongodb async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.mongodb_async)
            await gen.sleep(store.retry_interval())
