import os, json, copy, traceback, telnetlib, subprocess
from abc import ABCMeta, abstractmethod
from enum import Enum
from asyncio import wait_for, TimeoutError
from tornado.ioloop import IOLoop
from tornado.gen import sleep, multi
from mg_app_framework.config import Store, get_logger, set_handler, get_handler, get_uuid, get_organization, \
    get_rabbitmq_info, get_organization_all
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from inspect import iscoroutinefunction


class DbType(Enum):
    mongodb = 'mongodb'
    sqlite = 'sqlite'


class RabbitMQConfigBasic(metaclass=ABCMeta):
    def get_rabbitmq_host(self):
        return get_rabbitmq_info().get('host')

    def get_rabbitmq_port(self):
        return get_rabbitmq_info().get('port')

    def get_rabbitmq_username(self):
        return get_rabbitmq_info().get('username')

    def get_rabbitmq_password(self):
        return get_rabbitmq_info().get('password')

    def publish_config_data(self):
        """
        该配置项仅针对需要发布配置数据的app（如主数据、指标标准等）,
        新上线的app会向配置数据发布者请求一份最新的配置数据
        :return:True  -> 表示需要发布配置数据
                False -> 表示不需要发布配置数据
        """
        return False

    def get_rabbitmq_subscribe_list(self):
        """
        :return:返回订阅的数组
        [
            'kkk', # 消息索引
            'yyy', # 消息索引
            ...
        ]
        """
        return []

    @abstractmethod
    def message_process_func(self):
        """
        1. subscribe_list is not empty
        2. when receive message, call this function to process message
        message 数据格式:
        {
            'organization':'hhh' # 组织信息
            'key'  : 'kkk',      # 消息索引
            'data' : 'lll'       # 消息数据
        }
        # 消息处理函数:
        def rabbitmq_message_func_example(message):
            if msg['key'] == 'kkk':
                get_logger().info("msg: %s" % (str(message)))
            elif msg['key'] == 'yyy':
                get_logger().info("msg: %s" % (str(message)))

        :return:返回处理函数名(rabbitmq_message_func_example)
        """
        pass

    def set_database_for_persist_message(self):
        """
        持久化消息至本地时使用的数据库，注意：mongodb适用于linux机器上运行的app，而sqlite仅适用于iot设备，iot重连失败时可能触发重启进程或reboot
        动作，因此谨慎选择sqlite作为本地数据库
        """
        return 'mongodb'

    def set_sqlite_db_file_path(self):
        """
        设置sqlite储存数据的路径
        """
        return '/var/iot_message.db'

    def republish_fetch_message_num(self):
        '''
        :return: 重新发送时单次从sqlite取出数据条数
        '''
        return 10

    def set_disk_usage_alarm_threshold(self):
        '''
        设置iot磁盘使用率阈值
        :return:
        '''
        return 90

    def reconnect_interval(self):
        """
        :return:重连rabbitmq时间间隔, 默认 5 秒

        """
        return 5

    def set_qos_num(self):
        """
        :return:客户端能并发处理的未处理消息数量,默认10条

        """
        return 10

    def heartbeat_interval(self):
        '''

        :return: 连接rabbitmq成功后与服务端发送心跳时间间隔, 默认 ２０ 秒
        '''
        return 20

    def ack_before_message_process_func(self):
        '''
        在消息处理前还是处理前后ack
        :return:
        '''
        return True

    def publish_timeout(self):
        '''
        发布消息超时时间,默认５秒
        :return:
        '''
        return 5


class RabbitMQClient:
    def __init__(self, host, port, username, password, topic_list, queue_name, subscribe_list,
                 publish_config_data, database_for_persist_message, sqlite_db_file_path, reconnect_interval,
                 heartbeat_interval, republish_fetch_message_num, alarm_threshold, qos_num,
                 ack_before_message_process_func, publish_timeout, message_process_func=None):

        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.topic_list = topic_list
        self.queue_name = queue_name
        self.subscribe_list = subscribe_list
        self.publish_config_data = publish_config_data
        self.connection = None
        self.channel = None
        self.queue = None  # 一个app对应一个持久化队列
        self.topic = {}
        self.subscribe_message_cache = {}  # 数据格式{'root~test':'123'}
        self.publish_message_cache = {}  # 数据格式{'root~test':'123'}
        self.reconnect_interval = reconnect_interval
        self.message_process_func = message_process_func
        self.database_for_persist_message = database_for_persist_message
        self.local_mongodb_connection = None
        self.republish_fetch_message_num = republish_fetch_message_num
        self.alarm_threshold = alarm_threshold
        self.sqlite_db_file_path = sqlite_db_file_path
        self.heartbeat_interval = heartbeat_interval
        self.qos_num = qos_num
        self.ack_before_message_process_func = ack_before_message_process_func
        self.publish_timeout = publish_timeout
        self.republish_running = False
        self.reconnect_num = 0

    async def get_connection(self):
        # get rabbitmq connection ,if not exist create one
        from aio_pika import connect as aio_pika_connect
        # from aio_pika import connect_robust as aio_pika_connect
        if not self.connection:
            try:
                self.connection = await aio_pika_connect(host=self.host, port=self.port, login=self.username,
                                                         password=self.password,
                                                         timeout=2,  # aio-pika 6.4.1 参数
                                                         heartbeat=self.heartbeat_interval,  # aio-pika 6.4.1 参数
                                                         # socket_timeout=3,　# aio-pika 4.9.3参数
                                                         # heartbeat_interval=5  # aio-pika 4.9.3参数
                                                         )
                get_logger().info('connect rabbitmq success')

                await self.create_channel()
                self.connection.add_close_callback(self.on_connection_closed)

            except TimeoutError:
                get_logger().info('connect rabbitmq failed because of timeout')
            except Exception as e:
                get_logger().info('connect rabbitmq failed:%s', e)

        return self.connection

    async def create_channel(self):
        # create rabbitmq channel ,if not exist create one
        if not self.channel:
            try:
                self.channel = await self.connection.channel()
                await self.channel.set_qos(self.qos_num)
                get_logger().info('create channel success,qos num:%s', self.qos_num)
            except Exception as e:
                get_logger().info('connect channel failed because of %s', e)

        return self.channel

    async def create_topic(self, topic_name):
        # create topic_type exchange with given topic_name
        from aio_pika import ExchangeType

        try:
            exchange = await self.channel.declare_exchange(topic_name, ExchangeType.TOPIC, timeout=1)
            self.topic.update({topic_name: exchange})
            get_logger().info('create topic[%s] success', topic_name)
            if topic_name not in self.topic_list:
                self.topic_list.append(topic_name)
            return exchange
        except Exception as e:
            get_logger().info('create_topic failed:%s', e)

    async def create_topic_list(self, topic_list):
        # create topic_type exchange with given topic_list
        for topic_name in topic_list:
            await self.create_topic(topic_name)

    async def get_topic(self, topic_name):
        # get the topic_type exchange with given topic_name, if not exist create one
        exchange = self.topic.get(topic_name)
        if not exchange:
            exchange = await self.create_topic(topic_name)

        return exchange

    async def init_topic_and_queue(self):
        # create channel\topic\queue,and bind topic exchange with subscribe_list
        get_logger().info('start rabbitmq init process')
        await self.create_topic_list(self.topic_list)
        await self.create_queue(self.queue_name)
        await self.bind_routing_key(self.subscribe_list, self.topic_list)

        if self.publish_config_data:
            publish_key = 'new_subscriber_online'
            await self.bind_routing_key([publish_key], self.topic_list)

    async def send_subscribe_key_list_to_publisher(self, subscribe_list, topic_list):
        from aio_pika import Message, DeliveryMode

        for topic_name in topic_list:
            msg = {'key': 'new_subscriber_online', 'data': subscribe_list}
            exchange = await self.get_topic(topic_name)
            if exchange:
                message_body = json.dumps(msg).encode('utf-8')
                message = Message(message_body, delivery_mode=DeliveryMode.PERSISTENT)
                await exchange.publish(message, routing_key='new_subscriber_online')
                get_logger().info('send subscribe key list %s to topic[%s] success', subscribe_list, topic_name)

    async def publish_message(self, msg, topic_name, time_series_data, republish_message=False):
        # publish publish_key messages with topic exchange to queues,store the message if publish failed
        from aio_pika import Message, DeliveryMode

        publish_key = msg.get('key')
        publish_data = msg.get('data')

        # 检查是否满足发送条件
        publish_ready = True
        if not topic_name and not is_multi_tenant():
            topic_name = get_organization()

        if not topic_name and is_multi_tenant():
            error_msg = 'topic_name cannot be None under multi tenant pattern'
            publish_ready = False

        if not self.connection:
            error_msg = 'no connection'
            publish_ready = False

        exchange = await self.get_topic(topic_name)
        if not exchange:
            error_msg = 'no exchange'
            publish_ready = False

        # 执行发送逻辑
        publish_res = False
        if publish_ready:
            get_logger().debug('start publish key [%s] message', publish_key)

            if time_series_data:
                message = copy.deepcopy(msg)
                message.update({'time_series_data': True})
            else:
                message = msg
                message_key = pack_message_key(topic_name, publish_key)
                self.publish_message_cache.update({message_key: publish_data})
                await self.persist_publish_message_cache()

            message_body = json.dumps(message).encode('utf-8')
            message_data = Message(message_body, delivery_mode=DeliveryMode.PERSISTENT)

            try:
                await exchange.publish(message_data, routing_key=publish_key, timeout=self.publish_timeout)
                publish_res = True
                get_logger().info('publish key[%s] message to topic[%s] success', publish_key,
                                  topic_name)
            except TimeoutError:
                get_logger().info('publish key[%s] message to topic[%s] failed because of timeout', publish_key,
                                  topic_name)
            except Exception as e:
                get_logger().info('publish key[%s] message to topic[%s] failed because of %s', publish_key,
                                  topic_name, e)
        else:
            get_logger().info('publish key[%s] message to topic[%s] failed because of %s', publish_key,
                              topic_name, error_msg)

        # 检查发送结果
        if not publish_res:
            publish_failed_message = {'key': pack_message_key(topic_name, publish_key), 'data': publish_data}
            if not republish_message:  # 如果是重发消息时失败则不用存数据库
                await self.persist_publish_failed_message(publish_failed_message, time_series_data)

        else:
            ioloop = IOLoop.current()
            ioloop.spawn_callback(self.republish_persist_message)

        return publish_res

    async def create_queue(self, queue_name):
        # create a queue if not exist
        # 目前一个app对应一个queue
        try:
            self.queue = await self.channel.declare_queue(queue_name, durable=True)
            get_logger().info('create queue:[%s] success', queue_name)
        except Exception as e:
            get_logger().info('create queue fail because of %s', e)

    async def bind_routing_key(self, subscribe_key_list, topic_list):
        # bind queue and exchange with route_key

        for topic_name in topic_list:
            exchange = await self.get_topic(topic_name)
            if exchange:
                for subscribe_key in subscribe_key_list:
                    try:
                        await self.queue.bind(exchange, routing_key=subscribe_key)
                        get_logger().info('bind subscribe key[%s] to topic[%s] success', subscribe_key, topic_name)
                        if subscribe_key not in self.subscribe_list:
                            self.subscribe_list.append(subscribe_key)
                    except Exception as e:
                        get_logger().info('bind subscribe key[%s] to topic[%s] fail because of %s', subscribe_key,
                                          topic_name, e)
            else:
                get_logger().info('bind_routing_key fail because of no exchange')

    async def unbind_routing_key(self, routing_key_list, topic_list):
        for topic_name in topic_list:
            for routing_key in routing_key_list:
                try:
                    await self.queue.unbind(topic_name, routing_key)
                    get_logger().info('unbind routing_key[%s] to topic[%s]', routing_key, topic_name)
                    if routing_key in self.subscribe_list:
                        self.subscribe_list.remove(routing_key)
                except Exception as e:
                    get_logger().info('unbind routing_key[%s] to topic[%s] fail because of %s', routing_key, topic_name,
                                      e)

    async def listening_message(self):
        # 监听队列消息
        from aio_pika import IncomingMessage
        async def receive_message_callback(message: IncomingMessage):
            # 调用回调函数处理消息
            with message.process(ignore_processed=True):
                if self.ack_before_message_process_func:
                    message.ack()

                topic_name = message.exchange
                routing_key = message.routing_key

                if topic_name != 'amq.topic' and routing_key != 'new_subscriber_online' and routing_key not in self.subscribe_list:
                    await self.unbind_routing_key([routing_key], [topic_name])
                    get_logger().info('subscribe_key[%s] not exist in subscribe_list', routing_key)
                    return

                message_body = json.loads(message.body.decode("utf-8"))
                get_logger().debug('receive rabbitmq message from topic[%s] by routing_key[%s]', topic_name,
                                   routing_key)
                get_logger().debug('message_body==%s', message_body)

                # 处理消息
                formatted_message = await self.format_message(message_body, topic_name, routing_key)
                processed_message = await self.preprocess_message(formatted_message, routing_key, topic_name)
                if processed_message:
                    topic_name, routing_key = unpack_message_key(processed_message.get('key'))
                    execute_message = {'organization': topic_name, 'key': routing_key,
                                       'data': processed_message.get('data')}
                    await self.execute_message_process_func(execute_message)

                if not self.ack_before_message_process_func:
                    message.ack()

        if not self.connection:
            get_logger().info('listening_message fail because of no connection')
            return

        try:
            await self.queue.consume(receive_message_callback)
            get_logger().info('start listening_message')
        except Exception as e:
            get_logger().info('listening_message from queue fail because of %s', e)

    async def execute_message_process_func(self, execute_message):
        # 执行用户注册的消息处理函数
        if self.message_process_func:
            if iscoroutinefunction(self.message_process_func):
                await self.message_process_func(execute_message)
            else:
                self.message_process_func(execute_message)

    async def format_message(self, message_body, topic_name, routing_key):
        # 将消息格式化为 {'key':topic_name~routing_key,'data':data}形式
        message_key = pack_message_key(topic_name, routing_key)
        if isinstance(message_body, dict):
            if 'key' not in message_body.keys():  # MQTT上传的IOT数据
                message_body = {'key': message_key, 'data': message_body}
            else:  # AMQP格式数据
                message_body.update({'key': message_key})
        else:  # HTTP 测试数据
            message_body = {'key': message_key, 'data': message_body}

        return message_body

    async def preprocess_message(self, message, routing_key, topic_name):
        # 预处理消息，并更新订阅端缓存的配置数据
        message_key = message.get('key')
        message_data = message.get('data')
        is_time_series_data = message.get('time_series_data')

        # 直接返回业务数据
        if is_time_series_data:
            message.pop('time_series_data')
            return message

        # 处理新上线的订阅者请求
        if self.publish_config_data:
            # 处理新上线的mqtt lib订阅者发来的配置请求
            if topic_name == 'amq.topic':
                organization, key = unpack_message_key(routing_key, slash='.')
                if key == 'new_subscriber_online':
                    get_logger().info('receive new iot subscriber key_list %s from amq.topic', message_data)
                    for subscribe_key in message_data:
                        data = self.publish_message_cache.get(pack_message_key(organization, subscribe_key))
                        if data:
                            msg = {'key': subscribe_key, 'data': data}
                            await rabbitmq_publish_config_data_to_iot(msg)
                        else:
                            get_logger().debug('cannot publish key[%s] because cache data is None', subscribe_key)
                    return None

            # 处理amqp lib新上线的订阅者的配置请求
            if message_key == pack_message_key(topic_name, 'new_subscriber_online'):
                get_logger().info('receive list new subscriber key_list %s from topic[%s]', message_data, topic_name)
                for subscribe_key in message_data:
                    new_subscribe_key = pack_message_key(topic_name, subscribe_key)
                    data = self.publish_message_cache.get(new_subscribe_key)
                    if data:
                        msg = {'key': subscribe_key, 'data': data}
                        await self.publish_message(msg, topic_name, False)
                    else:
                        get_logger().debug(
                            'cannot publish key[%s] because cache data is None', subscribe_key)
                return None

        cache_message_data = self.subscribe_message_cache.get(message_key)
        if json.dumps(message_data) != json.dumps(cache_message_data):
            # 如果订阅到的消息和缓存里的消息不同则直接处理
            self.subscribe_message_cache.update({message_key: message_data})
            await self.persist_subscribe_message_cache()
            return message
        else:
            # 如果订阅到的消息和缓存里的消息相同则忽略
            get_logger().debug(
                'ignore message_key[%s] because of nothing changed comparing with subscribe_message_cache')
            return None

    def on_connection_closed(self, future):
        get_logger().warn('rabbitmq connection_closed')

        ioloop = IOLoop.current()
        ioloop.spawn_callback(self.clear_connection)

    async def clear_connection(self):
        await self.channel.close()
        await self.connection.close()
        self.connection = None
        self.channel = None
        self.queue = None
        self.topic = {}

    async def auto_reconnect(self):
        while True:
            if not self.connection or not self.channel:
                if await self.get_connection():
                    await self.init_topic_and_queue()
                    await self.listening_message()
                else:
                    self.reconnect_num += 1
                    get_logger().warn('rabbitmq async reconnect number: ' + str(self.reconnect_num))
                    # self.check_network_condition(self.reconnect_num)  # iot定制逻辑
            else:
                self.reconnect_num = 0

            await sleep(self.reconnect_interval)
            get_logger().debug('execute auto_reconnect')

    def check_network_condition(self, reconnect_num):
        '''
        重连20次均失败时检查网络是否通畅,iot定制逻辑
        :return:
        '''
        if self.database_for_persist_message == DbType.sqlite.value and reconnect_num > 60:
            if is_port_open(self.host, self.port):
                get_logger().info('reconnect failed and network is unavailable, start restart_process')
                self.restart_process()
            else:
                get_logger().info('reconnect failed but network is available, start restart_iot')
                self.restart_iot()

    def restart_process(self):
        '''
        重连失败但网络不通重启采集进程
        :return:
        '''
        p = subprocess.Popen('ps | grep run_idi_iot', shell=True, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)

        pid_list = []
        for line in p.stdout.readlines():
            info = line.decode('utf-8')
            if 'python' in info and 'run_idi_iot' in info:
                pid = str(int(info[:6]))
                if pid not in pid_list:
                    pid_list.append(pid)

        if pid_list:
            kill_cmd = 'kill -9 ' + ' '.join(pid_list)
            restart_process_cmd = kill_cmd + ';' + 'bash /home/root/idi_iot_0.0.4/bin/run.sh start'
            get_logger().info('start execute reconnect_fail_cmd:%s', restart_process_cmd)
            os.system(restart_process_cmd)
        else:
            get_logger().info('not found pid')

    def restart_iot(self):
        '''
        重连失败且网络不通时重启ｉｏｔ设备
        :return:
        '''
        restart_iot_cmd = 'reboot'
        get_logger().info('start execute reconnect_fail_cmd:%s', restart_iot_cmd)
        os.system(restart_iot_cmd)

    async def persist_subscribe_message_cache(self):
        # 持久化保存订阅端配置数据
        if self.database_for_persist_message == DbType.mongodb.value:
            try:
                db_connection = self.local_mongodb_connection
                db_name = 'rabbitmq_lib_' + get_uuid()
                db_handle = db_connection[db_name]
                from pymongo import DeleteMany, UpdateOne
                db_requests = [DeleteMany({'key': 'subscribe_message'}),
                               UpdateOne({'key': 'subscribe_message'},
                                         {'$set': {'data': self.subscribe_message_cache}},
                                         upsert=True)]
                await db_handle.subscribe_message.bulk_write(db_requests)
            except Exception as e:
                get_logger().info('persist_subscribe_message_cache to local mongodb failed:%s', e)

        elif self.database_for_persist_message == DbType.sqlite.value:
            pass

    async def persist_publish_message_cache(self):
        # 持久化保存发布端配置数据
        if self.database_for_persist_message == DbType.mongodb.value:
            try:
                db_connection = self.local_mongodb_connection
                db_name = 'rabbitmq_lib_' + get_uuid()
                db_handle = db_connection[db_name]
                from pymongo import DeleteMany, UpdateOne
                db_requests = [DeleteMany({'key': 'publish_message'}),
                               UpdateOne({'key': 'publish_message'}, {'$set': {'data': self.publish_message_cache}},
                                         upsert=True)]
                await db_handle.publish_message.bulk_write(db_requests)
            except Exception as e:
                get_logger().info('persist_publish_message_cache to local mongodb failed:%s', e)


        elif self.database_for_persist_message == DbType.sqlite.value:
            pass

    async def read_persist_message_to_cache(self):
        # 将本地数据库中持久化的订阅端和发布端消息恢复至内存中
        if self.database_for_persist_message == DbType.mongodb.value:
            try:
                db_connection = self.local_mongodb_connection
                db_name = 'rabbitmq_lib_' + get_uuid()
                db_handle = db_connection[db_name]

                # 恢复订阅端数据至缓存
                async for document in db_handle.subscribe_message.find({'_id': {'$ne': None}}, {'_id': 0}):
                    if is_multi_tenant():
                        self.subscribe_message_cache = document['data']
                    else:
                        for key, data in document['data'].items():
                            if '~' not in key:
                                self.subscribe_message_cache.update(
                                    {pack_message_key(get_organization(), key): data})
                            else:
                                self.subscribe_message_cache.update({key: data})

                # 恢复发布端数据至缓存
                async for document in db_handle.publish_message.find({'_id': {'$ne': None}}, {'_id': 0}):
                    if is_multi_tenant():
                        self.publish_message_cache = document['data']
                    else:
                        for key, data in document['data'].items():
                            if '~' not in key:
                                self.publish_message_cache.update({pack_message_key(get_organization(), key): data})
                            else:
                                self.publish_message_cache.update({key: data})

            except Exception as e:
                get_logger().info('read_persist_message_to_cache to local mongodb failed:%s', e)


        elif self.database_for_persist_message == DbType.sqlite.value:
            pass

    async def persist_publish_failed_message(self, message, time_series_data):
        # 持久化储存发送失败的消息至本地数据库
        if self.database_for_persist_message == DbType.mongodb.value:
            try:
                db_connection = self.local_mongodb_connection
                db_name = 'rabbitmq_lib_' + get_uuid()
                db_handle = db_connection[db_name]

                if time_series_data:
                    # 业务数据
                    await db_handle.publish_failed_time_series_data.insert_one(message)
                else:
                    # 配置数据
                    await db_handle.publish_failed_latest_data.update_one(
                        {'key': message.get('key')}, {'$set': message}, upsert=True)
                get_logger().info('persist_publish_failed_message to local mongodb finished')

            except Exception as e:
                get_logger().info('persist_publish_failed_message to local mongodb failed:%s', e)

        elif self.database_for_persist_message == DbType.sqlite.value:
            try:
                if time_series_data and (not get_disk_usage_alarm(self.alarm_threshold)):
                    from aiosqlite import connect as aiosqlite_connect
                    async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
                        await self.create_table_in_sqlite()
                        await sqlite_db.execute("INSERT INTO publish_failed_time_series_data VALUES (null,?)",
                                                (json.dumps(message),))
                        await sqlite_db.commit()
                        get_logger().info('persist_publish_failed_message to sqlite finished')

            except Exception as e:
                get_logger().info('persist_publish_failed_message to sqlite failed:%s', e)

    async def create_table_in_sqlite(self):
        table_list = []
        from aiosqlite import connect as aiosqlite_connect
        async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
            c = await sqlite_db.execute("SELECT name FROM sqlite_master WHERE type='table';")
            async for row in c:
                table_list.append(row[0])

            if 'publish_failed_time_series_data' not in table_list:
                await sqlite_db.execute("PRAGMA auto_vacuum = FULL;")
                await sqlite_db.execute(
                    '''create table IF NOT EXISTS publish_failed_time_series_data(message_id INTEGER PRIMARY KEY,message TEXT )''')
                get_logger().info('create_table_in_sqlite finished')

    async def republish_persist_message(self):
        # 将发送失败的消息从本地数据库（mongodb或sqlite）读取出来然后发布出去
        if not self.republish_running:
            self.republish_running = True  # 重新发布数据任务开始
            if self.database_for_persist_message == DbType.mongodb.value:
                try:
                    db_connection = self.local_mongodb_connection
                    db_name = 'rabbitmq_lib_' + get_uuid()
                    db_handle = db_connection[db_name]

                    # 业务数据
                    async for data in db_handle.publish_failed_time_series_data.find({'_id': {'$ne': None}},
                                                                                     {'_id': 0}):
                        topic_name, message_key = unpack_message_key(data.get('key'))
                        message = {'key': message_key, 'data': data.get('data')}
                        await self.publish_message(message, topic_name, True, republish_message=True)
                    await db_handle.publish_failed_time_series_data.drop()

                    # 配置数据
                    async for data in db_handle.publish_failed_latest_data.find({'_id': {'$ne': None}}, {'_id': 0}):
                        topic_name, message_key = unpack_message_key(data.get('key'))
                        message = {'key': message_key, 'data': data.get('data')}
                        await self.publish_message(message, topic_name, False, republish_message=True)
                    await db_handle.publish_failed_latest_data.drop()
                    get_logger().debug('republish_persist_message from mongodb finished')

                except Exception as e:
                    get_logger().info('republish_persist_message from mongodb failed:%s', e)
                finally:
                    self.republish_running = False  # 重新发布数据任务结束

            elif self.database_for_persist_message == DbType.sqlite.value:
                try:
                    table_list = []
                    from aiosqlite import connect as aiosqlite_connect
                    async with aiosqlite_connect(self.sqlite_db_file_path) as sqlite_db:
                        c = await sqlite_db.execute("SELECT name FROM sqlite_master WHERE type='table';")
                        async for row in c:
                            table_list.append(row[0])

                        if 'publish_failed_time_series_data' in table_list:
                            while True:
                                select_sql = "SELECT message_id, message FROM publish_failed_time_series_data where message_id>=0 limit {}".format(
                                    self.republish_fetch_message_num)
                                async with sqlite_db.execute(select_sql) as cursor:
                                    rows = await cursor.fetchmany(self.republish_fetch_message_num)
                                    if (not rows) or (not self.connection):
                                        break

                                    coro_dict = {}
                                    for row in rows:
                                        message_id, data = row[0], json.loads(row[1])
                                        topic_name, message_key = unpack_message_key(data.get('key'))
                                        message = {'key': message_key, 'data': data.get('data')}
                                        coro_dict[str(message_id)] = self.publish_message(message, topic_name, True,
                                                                                          republish_message=True)
                                    results = await multi(coro_dict)

                                    publish_success_id_list = [id for id, res in results.items() if res]
                                    delete_list = '(' + ','.join(publish_success_id_list) + ')'
                                    delete_sql = "delete FROM publish_failed_time_series_data where message_id IN {}".format(
                                        delete_list)
                                    await sqlite_db.execute(delete_sql)
                                    await sqlite_db.commit()

                            if self.connection:
                                await sqlite_db.execute('DROP TABLE publish_failed_time_series_data')
                                await sqlite_db.execute("VACUUM")
                                await sqlite_db.commit()
                                get_logger().debug('republish job finished')
                            else:
                                get_logger().info('republish job paused because of connection is None')

                except  Exception as e:
                    get_logger().info('republish persist message from sqlite failed:%s', e)
                finally:
                    self.republish_running = False  # 重新发布数据任务停止

        else:
            get_logger().debug('republish job is running')

    async def create_connection_to_database_for_persist(self):
        if self.database_for_persist_message == DbType.mongodb.value:
            await self.connect_to_local_mongodb()
        elif self.database_for_persist_message == DbType.sqlite.value:
            await self.connect_to_local_sqlite()

    async def connect_to_local_mongodb(self):
        from motor.motor_tornado import MotorClient
        if not self.local_mongodb_connection:
            self.local_mongodb_connection = MotorClient('127.0.0.1', serverSelectionTimeoutMS=1000)
            try:
                await self.local_mongodb_connection.server_info()
                get_logger().info('mq_lib connect local mongodb success')
            except:
                get_logger().warn('mq_lib connect local mongodb failed')

    async def connect_to_local_sqlite(self):
        pass


async def rabbitmq_publish_many(datas, time_series_data=False):
    '''
    :param datas:
                    # [
                    # {
                    #     'organization':'realtech'
                    #     'key': key_name1,
                    #     'data': ...
                    # },
                    # {
                    #     'organization':'realtech'
                    #     'key': key_name2,
                    #     'data': ...
                    # },
                    # ]
    :param time_series_data: 是否为时序数据（业务数据）
    :return:
    '''

    await multi([rabbitmq_publish_one(data, time_series_data) for data in datas])


async def rabbitmq_publish_one(data, time_series_data=False):
    '''
    :param data:    # {
                    #   'organization':'realtech'
                    #   'key': key_name,
                    #   'data': ...
                    # }
    :param time_series_data: 是否为时序数据（业务数据）
    :return:
    '''

    topic_name = data.pop('organization', None)
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    await rabbitmq_handler.publish_message(data, topic_name, time_series_data)


async def rabbitmq_publish_config_data_to_iot(data):
    '''
    向使用mqtt lib的iot设备发送配置数据
    :param data:    # {
                    #   'key': key_name,
                    #   'data': ...
                    # }
    :return:
    '''
    from aio_pika import ExchangeType, Message, DeliveryMode

    topic_name, message_key = 'amq.topic', data.get('key')
    organization = get_organization()
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    exchange = await rabbitmq_handler.channel.declare_exchange(topic_name, ExchangeType.TOPIC, durable=True)
    publish_key = pack_message_key(organization, message_key, slash='.')
    message_body = json.dumps(data).encode('utf-8')
    message_data = Message(message_body, delivery_mode=DeliveryMode.PERSISTENT)
    await exchange.publish(message_data, routing_key=publish_key)
    rabbitmq_handler.publish_message_cache.update({pack_message_key(organization, message_key): data.get('data')})
    get_logger().info('publish key [%s] config data to iot success', message_key)


async def prcoess_iot_request_for_config_data():
    '''
    处理新上线的iot配置数据请求
    :return:
    '''
    topic_name = 'amq.topic'
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    routing_key = pack_message_key(get_organization(), 'new_subscriber_online', slash='.')
    await rabbitmq_handler.queue.bind(topic_name, routing_key)
    get_logger().info('bind key [%s] to amq.topic finished', routing_key)


async def rabbitmq_get_publish_message_cache():
    # 获取发布端缓存
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    if is_multi_tenant():
        message_cache = rabbitmq_handler.publish_message_cache
    else:
        message_cache = {}
        for message_key, data in rabbitmq_handler.publish_message_cache.items():
            topic, key = unpack_message_key(message_key)
            message_cache.update({key: data})

    return message_cache


async def rabbitmq_delete_publish_message_cache_key(key_name, topic_name=None):
    # 删除发布端缓存内某个key
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    topic = topic_name if topic_name else get_organization()
    key = pack_message_key(topic, key_name)
    if key in rabbitmq_handler.publish_message_cache.keys():
        del rabbitmq_handler.publish_message_cache[key]

    get_logger().info('delete key[%s] in topic[%s] cache success', key_name, topic)


async def rabbitmq_get_subscribe_message_cache():
    # 获取订阅端缓存
    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    if is_multi_tenant():
        message_cache = rabbitmq_handler.subscribe_message_cache
    else:
        message_cache = {}
        for message_key, data in rabbitmq_handler.subscribe_message_cache.items():
            topic, key = unpack_message_key(message_key)
            message_cache.update({key: data})

    return message_cache


async def rabbitmq_bind_subscribe_key_to_topic(subscribe_key_list, topic_list=None):
    '''
    用routing_key将queue和topic绑定起来
    :param subscribe_key_list: 需要订阅的key list
    :param topic_list: 绑定的topic list
    :return:
    '''
    if not topic_list:
        topic_list = [get_organization()]

    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    await rabbitmq_handler.bind_routing_key(subscribe_key_list, topic_list)
    get_logger().info('bind subscribe_key%s to topic%s success', subscribe_key_list, topic_list)


async def rabbitmq_unbind_subscribe_key_to_topic(subscribe_key_list, topic_list=None):
    '''
    用routing_key将queue和topic解除绑定
    :param subscribe_key_list: 需要解除订阅的key list
    :param topic_list: topic list
    :return:
    '''
    if not topic_list:
        topic_list = [get_organization()]

    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    await rabbitmq_handler.unbind_routing_key(subscribe_key_list, topic_list)
    get_logger().info('unbind subscribe_key%s to topic%s success', subscribe_key_list, topic_list)


async def get_subscribe_key_data_from_publisher(subscribe_key_list, topic_list=None):
    '''
    向配置数据发布者请求最新的配置数据
    :param subscribe_key_list: 订阅的key list
    :param topic_list: publisher所在的组织
    :return:
    '''
    if not topic_list:
        topic_list = [get_organization()]

    rabbitmq_handler = get_handler(TaskKey.rabbitmq_async)
    await rabbitmq_handler.send_subscribe_key_list_to_publisher(subscribe_key_list, topic_list)


def pack_message_key(topic_name, routing_key, slash='~'):
    # 将topic_name和routing_key包装成新的message key
    return slash.join([topic_name, routing_key])


def unpack_message_key(message_key, slash='~'):
    return message_key.split(slash)


def is_multi_tenant():
    # 是否为多租户模式
    return Store.store.is_multi_tenant()


def get_disk_usage_alarm(alarm_threshold):
    '''
    磁盘使用率超过阈值则告警
    :return:
    '''
    import psutil
    disk_usage_alarm = False
    disk_info = psutil.disk_usage('/')
    percent = round(disk_info.percent, 2)
    if percent > alarm_threshold:
        disk_usage_alarm = True
        get_logger().info('disk usage[%s] higher than threshold[%s]', percent, alarm_threshold)

    return disk_usage_alarm


def is_port_open(ip, port):
    is_open = False
    try:
        tn = telnetlib.Telnet(ip, port, timeout=1)
        is_open = True
        tn.close()
    except:
        pass

    return is_open


class RabbitMQConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def rabbitmq_async_connect(conn_time=None):
    # 　初始化连接配置
    if is_multi_tenant():
        topic_list = [organization.get('org_code') for organization in get_organization_all()]
    else:
        topic_list = [get_organization()]

    store = Store.get_init_task_config(TaskKey.rabbitmq_async)
    host = store.get_rabbitmq_host()
    port = int(store.get_rabbitmq_port())
    username = store.get_rabbitmq_username()
    password = store.get_rabbitmq_password()
    publish_config_data = store.publish_config_data()
    subscribe_list = store.get_rabbitmq_subscribe_list()
    queue_name = get_uuid()
    message_process_func = store.message_process_func()
    database_for_persist_message = store.set_database_for_persist_message()
    sqlite_db_file_path = store.set_sqlite_db_file_path()
    republish_fetch_message_num = store.republish_fetch_message_num()
    alarm_threshold = store.set_disk_usage_alarm_threshold()
    reconnect_interval = store.reconnect_interval()
    heartbeat_interval = store.heartbeat_interval()
    qos_num = store.set_qos_num()
    ack_before_message_process_func = store.ack_before_message_process_func()
    publish_timeout = store.publish_timeout()

    rabbitmq_handler = RabbitMQClient(host, port, username, password, topic_list, queue_name, subscribe_list,
                                      publish_config_data, database_for_persist_message, sqlite_db_file_path,
                                      reconnect_interval, heartbeat_interval, republish_fetch_message_num,
                                      alarm_threshold, qos_num, ack_before_message_process_func, publish_timeout,
                                      message_process_func)

    await rabbitmq_handler.create_connection_to_database_for_persist()
    await rabbitmq_handler.read_persist_message_to_cache()

    # 建立连接
    await rabbitmq_handler.get_connection()  # create connection
    set_handler(TaskKey.rabbitmq_async, rabbitmq_handler)
    if rabbitmq_handler.connection:
        await rabbitmq_handler.init_topic_and_queue()
        await rabbitmq_handler.send_subscribe_key_list_to_publisher(subscribe_list, topic_list)

    start_next_task(TaskKey.rabbitmq_async)
    loop = Store.get_loop()
    loop.spawn_callback(rabbitmq_handler.auto_reconnect)
