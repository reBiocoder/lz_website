from abc import ABCMeta, abstractmethod
from tornado import gen

from mg_app_framework.config import Store, set_handler, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class MysqlConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class MysqlConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_mysql_host(self):
        pass

    @abstractmethod
    def get_mysql_port(self):
        pass

    @abstractmethod
    def get_mysql_user(self):
        pass

    @abstractmethod
    def get_mysql_password(self):
        pass

    @abstractmethod
    def get_mysql_db(self):
        pass

    def get_mysql_charset(self):
        return 'utf8'

    def retry_interval(self):
        return 5

    def create_pool(self):
        return False


# connect to mysql_server
async def mysqldb_connect(re_conn=True, conn_time=None):
    import pymysql
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Mysql connect error,connect more than ' + str(conn_time) + ' times')
                raise MysqlConnectError
            store = Store.get_init_task_config(TaskKey.mysql)
            mysql_host = store.get_mysql_host()
            mysql_port = store.get_mysql_port()
            mysql_user = store.get_mysql_user()
            mysql_password = store.get_mysql_password()
            mysql_db = store.get_mysql_db()
            mysql_charset = store.get_mysql_charset()
            connector = pymysql.connect(host=mysql_host, user=mysql_user, password=mysql_password,
                                        db=mysql_db, port=mysql_port, charset=mysql_charset)
            get_logger().info('mysql connected successfully')
            set_handler(TaskKey.mysql, connector)
            if not re_conn:
                start_next_task(TaskKey.mysql)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('mysql connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.mysql)
            await gen.sleep(store.retry_interval())


# connect to mysql_server
async def mysqldb_async_connect(re_conn=True, conn_time=None):
    import aiomysql
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Mysql connect error,connect more than ' + str(conn_time) + ' times')
                raise MysqlConnectError
            store = Store.get_init_task_config(TaskKey.mysql_async)
            mysql_host = store.get_mysql_host()
            mysql_port = store.get_mysql_port()
            mysql_user = store.get_mysql_user()
            mysql_password = store.get_mysql_password()
            mysql_db = store.get_mysql_db()
            mysql_charset = store.get_mysql_charset()
            is_pool = store.create_pool()
            if is_pool:
                connector = await aiomysql.create_pool(host=mysql_host, port=mysql_port, user=mysql_user,
                                                       password=mysql_password, db=mysql_db, charset=mysql_charset)
            else:
                connector = await aiomysql.connect(host=mysql_host, port=mysql_port, user=mysql_user,
                                                   password=mysql_password, db=mysql_db, charset=mysql_charset)
            get_logger().info('mysql async connected successfully')
            set_handler(TaskKey.mysql_async, connector)
            if not re_conn:
                start_next_task(TaskKey.mysql_async)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('mysql async connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.mysql_async)
            await gen.sleep(store.retry_interval())
