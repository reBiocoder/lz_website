import tornado.web
import json
from tornado import gen
from tornado.httpclient import AsyncHTTPClient
from mg_app_framework.config import Store, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task
from mg_app_framework.client import HttpClient
from mg_app_framework.message import MesCode, send_alarm, AlarmLevel
from inspect import iscoroutinefunction
from abc import ABCMeta, abstractmethod


class SdsConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


async def sds_init_func(conn_time=None):
    store = Store.get_init_task_config(TaskKey.sds)
    is_sync = store.init_sync()
    if is_sync is False:
        # 异步，不阻塞后面的初始化任务
        start_next_task(TaskKey.sds)

    if is_sds_enabled():
        await send_init_to_sds(conn_time=conn_time)

    if is_sync is True:
        # 同步，阻塞后面的初始化任务
        start_next_task(TaskKey.sds)


class SdsConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_produce_list(self):
        """
        返回的数组类似于 produce_list:
        [
            # 第一条消息
            {
                'key'  : 'bbb', # 消息索引
                'data' : {}     # 消息数据
            },
            # 第二条消息
            {
                'key'  : 'kkk',
                'data' : {}
            }
            ...
        ]
        :return:
        """
        return []

    @abstractmethod
    def get_consume_list(self):
        """
        返回的数组类似于 consume_list:
        [
            'kkk', # 消息索引
            'yyy', # 消息索引
            ...
        ]
        :return:
        """
        return []

    @abstractmethod
    def msg_process(self, data):
        """
        1. consume_list is not empty
        2. when receive msg, pass data to this function
        :param 入参类似于 data:
        [
            # 第一条消息
            {
                'key'  : 'kkk',  # 消息索引
                'data' : {}      # 消息数据
            },
            # 第二条消息
            {
                'key'  : 'yyy',
                'data' : {}
            }
            ...
        ]
        # 消息处理使用循环:
        for msg in data:
            if msg['key'] == 'kkk':
                get_logger().info("msg: %s" % (str(data)))
            elif msg['key'] == 'yyy':
                get_logger().info("msg: %s" % (str(data)))

        :return:
        """
        pass

    def get_sds_host(self):
        """
        返回sds服务器ip, 默认与 mg_manager 部署在一起, 使用 get_admin_host 获取配置的 ip
        :return:
        """
        return Store.store.get_admin_host()

    def retry_interval(self):
        """
        sds重连时间间隔, 默认 30 秒
        :return:
        """
        return 30

    def init_sync(self):
        """
        标记sds重连任务是异步还是同步, 默认 True (同步)
        :return:
                False,异步执行;
                True, 同步执行;
        """
        return True

    @abstractmethod
    def get_organization_code(self):
        """
        获取当前组织编码，暂时用于支持开曼部署，后续需要通过框架进行优化
        """
        pass


def is_sds_enabled():
    store = Store.get_init_task_config(TaskKey.sds)
    if store:
        return True
    else:
        return False


# client send to sds
def get_sds_init_url():
    return '/api/v1/sds/app-init'


def get_sds_msg_url():
    return '/api/v1/sds/app-msg'


def get_sds_port():
    return 8088


# sds send to client
def get_app_online_url():
    return [
        (r'/api/v1/sds/on-line', SdsOnlineHandler),
    ]


def get_app_msg_url():
    return [
        (r'/api/v1/sds/msg', SdsMessageHandler),
    ]


def make_http_response(code, data=None, info=None):
    return {'code': code, 'data': data, 'info': info}


Retry = 0


class SdsOnlineHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")

    async def post(self):
        num_data = {}
        get_logger().info("[SDS] receive msg sds-online: [Retry %s]" % str(Retry))
        response_data = make_http_response(MesCode.success, num_data, 'Client Receive sds online msg')
        self.finish(json.dumps(response_data, ensure_ascii=False))
        if 0 == Retry:
            # Retry不等于0则是应用正在尝试与sds重连,此处不再重复发送init
            await send_init_to_sds()


class SdsMessageHandler(tornado.web.RequestHandler):
    def set_default_headers(self):
        self.set_header("Access-Control-Allow-Origin", "*")

    async def post(self):
        response_data = make_http_response(MesCode.success, {}, 'Client Receive sds forward msg')
        self.finish(json.dumps(response_data, ensure_ascii=False))
        data = json.loads(self.request.body.decode('utf-8'))
        await run_msg_process_func(data)


async def run_get_func(func):
    if iscoroutinefunction(func):
        return await func()
    else:
        return func()


async def run_msg_process_func(data):
    store = Store.get_init_task_config(TaskKey.sds)
    fun = store.msg_process
    if iscoroutinefunction(fun):
        await fun(data)
    else:
        fun(data)

# sds组织名和编码间隔符
ORGANIZATION_DELIMITER = '!'


def unpack_consume_key(consume_key):
    """
    将从sds获取到的消费者的带有organization_code的key解包
    :param consume_key: sds消息数据内的key
    :return: organization_code和原始的key
    """
    organization_code = None
    original_key = None
    index = consume_key.rfind(ORGANIZATION_DELIMITER)
    if index > 0:
        organization_code = consume_key[:index]
        original_key = consume_key[index+1:]
    return organization_code, original_key


def update_producer_sds_key_with_organization_code(sds_data_list, organization_code):
    if sds_data_list:
        for sds_data in sds_data_list:
            for key, value in sds_data.items():
                if key.lower() == 'key':
                    sds_data[key] = '{}{}{}'.format(organization_code, ORGANIZATION_DELIMITER, value)


def update_consumer_sds_key_with_organization_code(sds_key_list, organization_code):
    if sds_key_list:
        for i, key in enumerate(sds_key_list):
            sds_key_list[i] = '{}{}{}'.format(organization_code, ORGANIZATION_DELIMITER, key)


async def send_init_to_sds(conn_time=None):
    format_data = {}
    store = Store.get_init_task_config(TaskKey.sds)
    get_produce_list = store.get_produce_list
    # 从sds配置中获取组织编码并将该编码添加到produce_list中每个key上，目前用于区别多工厂数据
    organization_code = store.get_organization_code()
    produce_list = await run_get_func(get_produce_list)
    update_producer_sds_key_with_organization_code(produce_list, organization_code)
    format_data['produce'] = produce_list

    get_consume_list = store.get_consume_list
    # 对于sds消费者也需要给每个订阅的key添加组织编码
    consume_list = await run_get_func(get_consume_list)
    update_consumer_sds_key_with_organization_code(consume_list, organization_code)
    format_data['consume'] = consume_list

    format_data['port'] = Store.get_app_port()
    url = 'http://' + store.get_sds_host() + ':' + str(get_sds_port()) + get_sds_init_url()
    interval = store.retry_interval()
    global Retry
    while True:
        try:
            if conn_time and Retry == int(conn_time):
                get_logger().error('[SDS] connect error,connect more than ' + str(conn_time) + ' times')
                raise SdsConnectError
            client = HttpClient(AsyncHTTPClient(max_clients=1000))
            response = await client.post(url=url, data=format_data, headers={"Content-type": "json"})
            client.close()
            Retry = 0
            get_logger().info('[SDS] code: %s, info: %s' % (response.code, response.info))
            if not conn_time and Retry != 0:
                # 永久重试, 成功后发送一次告警解除
                send_alarm('Connecting to sds(%s) success.' % (store.get_sds_host() + ':' + str(get_sds_port())),
                           AlarmLevel.positive)
            break
        except Exception as e:
            Retry += 1
            if not conn_time and Retry == 1:
                # 永久重试, 第一次重试发送告警
                send_alarm('Connecting to sds(%s) fail. Please check if sds is online.' % (
                        store.get_sds_host() + ':' + str(get_sds_port())))
                get_logger().exception(e)
            await gen.sleep(interval)

    if len(response.data) > 0:
        await run_msg_process_func(response.data)


async def send_msg_to_sds(protocol, msg_list):
    """
    封装httpclient发送消息
    :param protocol:  http / https
    :param msg_list:    [
                            {'key': 'ppp1', 'data':{}},
                            {'key': 'ppp2', 'data':{}},
                        ]
    :return:
    """
    store = Store.get_init_task_config(TaskKey.sds)
    organization_code = store.get_organization_code()
    # 发送消息出去时，更新key添加organization_code
    update_producer_sds_key_with_organization_code(msg_list, organization_code)
    url = protocol + "://" + store.get_sds_host() + ':' + str(get_sds_port()) + get_sds_msg_url()
    try:
        client = HttpClient(AsyncHTTPClient(max_clients=1000))
        response = await client.post(url=url, data={'msg_list': msg_list}, headers={'Content-type': 'json'})
        get_logger().info("[SDS] send_msg_to_sds: [url %s] [code %s] [msg_keys %s]" % (
            url, response.code, str([it['key'] for it in msg_list])))
        client.close()
    except Exception as e:
        get_logger().exception(e)
