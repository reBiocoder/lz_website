from abc import ABCMeta, abstractmethod
from tornado import gen
from mg_app_framework.config import Store, set_handler, get_logger
from mg_app_framework.components import TaskKey
from mg_app_framework.process import start_next_task


class OracleConnectError(Exception):
    def __init__(self):
        Store.get_loop().stop()


class OracleConfigBasic(metaclass=ABCMeta):
    @abstractmethod
    def get_oracle_host(self):
        pass

    @abstractmethod
    def get_oracle_port(self):
        pass

    @abstractmethod
    def get_oracle_user(self):
        pass

    @abstractmethod
    def get_oracle_password(self):
        pass

    @abstractmethod
    def get_oracle_db(self):
        pass

    def retry_interval(self):
        return 5


# connect to oracle_server
async def oracle_connect(re_conn=True, conn_time=None):
    import cx_Oracle
    __cnt = 0
    while True:
        try:
            if conn_time and __cnt == int(conn_time):
                get_logger().error('Oracle connect error,connect more than ' + str(conn_time) + ' times')
                raise OracleConnectError
            store = Store.get_init_task_config(TaskKey.oracle)
            oracle_host = store.get_oracle_host()
            oracle_port = store.get_oracle_port()
            oracle_user = store.get_oracle_user()
            oracle_password = store.get_oracle_password()
            oracle_db = store.get_oracle_db()
            connector = cx_Oracle.connect(
                oracle_user + '/' + oracle_password + '@' + oracle_host + ':' + oracle_port + '/' + oracle_db)
            get_logger().info('oracle connected successfully')
            set_handler(TaskKey.oracle, connector)
            if not re_conn:
                start_next_task(TaskKey.oracle)
                break
            else:
                return connector
        except Exception:
            __cnt += 1
            get_logger().exception('oracle connecting retry number: ' + str(__cnt))
            store = Store.get_init_task_config(TaskKey.oracle)
            await gen.sleep(store.retry_interval())
