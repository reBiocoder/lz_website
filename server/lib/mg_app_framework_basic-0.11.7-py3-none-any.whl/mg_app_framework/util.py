from mg_app_framework.config import Store, get_uuid, get_logger
from mg_app_framework.client import HttpClient
from mg_app_framework.message import MesCode
import json
import traceback


# 登录以及权限检查 装饰器
def loginrequired(method):
    async def wrapper(self, *args, **kwargs):
        login_switch = Store.store.get_login_switch()
        if not login_switch:
            return await method(self, *args, **kwargs)
        else:
            login_uuid = self.get_cookie('login_uuid')
            union_id = None
            if not login_uuid:
                # 如果cookie中未获取到login_uuid, 尝试从request body中获取
                # 这里用于app间发送数据, 框架包装的client封装中包含了请求方登录信息
                if self.request.body:
                    body_data = json.loads(self.request.body.decode('utf-8'))
                    if 'manugence_login_uuid' in body_data:
                        login_uuid = body_data['manugence_login_uuid']
                if 'unionid' in self.request.headers:
                    union_id = self.request.headers['unionid']
            result = dict()
            result['app_group'] = Store.get_app_group()
            result['app_name'] = Store.get_app_name()
            login_url = Store.get_login_url()

            if login_uuid:
                client = HttpClient()
                app_uuid = get_uuid()
                if app_uuid:
                    login_role_check_url = login_url + '/api/auth/check_login_role'
                    post_data = {'login_uuid': str(login_uuid), 'app_uuid': str(app_uuid), 'func_name': str(self.__class__.__name__)}
                    res = await client.post(login_role_check_url, data=post_data)
                    res_code = res.code
                    res_mes = res.info
                    if res_code == MesCode.success:
                        return await method(self, *args, **kwargs)
                    else:
                        result["code"] = res_code
                        result["info"] = res_mes
                        result["data"] = None
                        if res_code == MesCode.login:
                            result["data"] = {'login_url': login_url, 'app_id': app_uuid}
                        self.finish(json.dumps(result, ensure_ascii=False))
                        return
                else:
                    result["code"] = MesCode.fail
                    result["data"] = None
                    result["info"] = '无法获取appid 异常'
                    self.finish(json.dumps(result, ensure_ascii=False))
                    return
            elif union_id:
                # 处理微信小程序的认证问题，微信小程序只有unionid, 无法设置cookie
                client = HttpClient()
                app_uuid = get_uuid()
                if app_uuid:
                    login_role_check_url = login_url + '/api/auth/check_login_role'
                    post_data = {'unionid': str(union_id), 'app_uuid': str(app_uuid), 'func_name': str(self.__class__.__name__)}
                    res = await client.post(login_role_check_url, data=post_data)
                    res_code = res.code
                    res_mes = res.info
                    if res_code == MesCode.success:
                        return await method(self, *args, **kwargs)
                    else:
                        result["code"] = res_code
                        result["info"] = res_mes
                        result["data"] = None
                        self.finish(json.dumps(result, ensure_ascii=False))
                        return
            else:
                result["code"] = MesCode.login
                result["data"] = {'login_url': login_url, 'app_id': get_uuid()}
                result["info"] = '登录超时，请重新登录'
                self.finish(json.dumps(result, ensure_ascii=False))
                return

    return wrapper


# 小数点格式转换接口
def decimal_format(num, digit=None):
    if digit is None:
        if isinstance(num, list):
            result = []
            for i in num:
                i = float(i)
                if i < 1:
                    i_result = '%.4f' % i
                elif 1 <= i < 1000:
                    i_result = '%.2f' % i
                else:
                    i_result = str(int(i))
                result.append(i_result)
        else:
            num = float(num)
            if num < 1:
                result = '%.4f' % num
            elif 1 <= num < 1000:
                result = '%.2f' % num
            else:
                result = str(int(num))
    else:
        if digit > 0:
            rule = '%.' + str(digit) + 'f'
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = rule % i
                    result.append(i_result)
            else:
                result = rule % num
        else:
            if isinstance(num, list):
                result = []
                for i in num:
                    i_result = str(int(i))
                    result.append(i_result)
            else:
                result = str(int(num))
    return result


# 主数据时间格式转换为cron定时格式
def cron_format(cron_unit):
    return_cron_format = {
            "year": "*",
            "month": "*",
            "day": "*",
            "day_of_week": "*",
            "hour": "*",
            "minute": "*",
            "second": "*",
        }
    if cron_unit == '小时':
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '两小时':
        return_cron_format['hour'] = '0,2,4,6,8,10,12,14,16,18,20,22'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '四小时':
        return_cron_format['hour'] = '0,4,8,12,16,20'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '八小时':
        return_cron_format['hour'] = '0,8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '半天':
        return_cron_format['hour'] = '0,12'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '天':
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '周':
        return_cron_format['day_of_week'] = '0'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '月':
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '年':
        return_cron_format['month'] = '1'
        return_cron_format['day'] = '1'
        return_cron_format['hour'] = '0'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'
    elif cron_unit == '分钟':
        return_cron_format['second'] = '0'
    elif cron_unit == '白班':
        return_cron_format['hour'] = '8,16'
        return_cron_format['minute'] = '0'
        return_cron_format['second'] = '0'

    return return_cron_format


def log_exception(e, err_info=''):
    """
    记录代码执行异常信息包括traceback
    :param e: 异常exception
    :param err_info: 可选填的错误信息
    """
    traceback_str = ''.join(traceback.format_tb(e.__traceback__))
    if err_info:
        err_msg = '{}, 异常信息: {}\n'.format(err_info, str(e))
    else:
        err_msg = '异常信息: {}\n'.format(str(e))
    get_logger().error(err_msg)
    get_logger().error('\n')
    get_logger().error('traceback信息: {0}'.format(traceback_str))
